package com.jordi.trikivalscreatures.client.model;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import java.util.Optional;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4945;

public class ModModels {
    public static final class_4942 TEMPLATE_PEJELAGARTO_EGG = block("template_pejelagarto_egg", class_4945.field_23010);
    public static final class_4942 TEMPLATE_TWO_PEJELAGARTO_EGGS = block("template_two_pejelagarto_egg", class_4945.field_23010);
    public static final class_4942 TEMPLATE_THREE_PEJELAGARTO_EGGS = block("template_three_pejelagarto_egg", class_4945.field_23010);
    public static final class_4942 TEMPLATE_FOUR_PEJELAGARTO_EGGS = block("template_four_pejelagarto_egg", class_4945.field_23010);

    private static class_4942 block(String parent, class_4945... requiredTextureKeys) {
        return new class_4942(Optional.of(class_2960.method_60655(TrikiValsCreatures.MOD_ID,
                "block/" + parent)), Optional.empty(), requiredTextureKeys);
    }
}
