package com.jordi.trikivalscreatures.client.model;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import java.util.function.UnaryOperator;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModModelIds {
    public static class_2960 getNamespacedBlock(String name) {
        return class_2960.method_60655(TrikiValsCreatures.MOD_ID, "block/" + name);
    }

    public static class_2960 getNamespacedItem(String name) {
        return class_2960.method_60655(TrikiValsCreatures.MOD_ID, "item/" + name);
    }

    public static class_2960 getBlockSubModelId(class_2248 block, String suffix) {
        class_2960 identifier = class_7923.field_41175.method_10221(block);
        return identifier.method_45134((UnaryOperator<String>)(path -> "block/" + path + suffix));
    }

    public static class_2960 getBlockModelId(class_2248 block) {
        class_2960 identifier = class_7923.field_41175.method_10221(block);
        return identifier.method_45138("block/");
    }

    public static class_2960 getItemModelId(class_1792 item) {
        class_2960 identifier = class_7923.field_41178.method_10221(item);
        return identifier.method_45138("item/");
    }

    public static class_2960 getItemSubModelId(class_1792 item, String suffix) {
        class_2960 identifier = class_7923.field_41178.method_10221(item);
        return identifier.method_45134((UnaryOperator<String>)(path -> "item/" + path + suffix));
    }
}
