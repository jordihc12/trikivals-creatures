package com.jordi.trikivalscreatures.client.tint;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_10401;
import net.minecraft.class_10402;
import net.minecraft.class_1309;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_638;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.class_9848;
import org.jetbrains.annotations.Nullable;

/**
 * Item tint that colors the fins drawn on the DracoPez bucket with the fin color stored in the bucket.
 * Used in assets/trikivals-creatures/items/dracopez_bucket.json as "trikivals-creatures:dracopez_fins".
 */
public record DracoPezFinsTintSource() implements class_10401 {
    public static final class_2960 ID = class_2960.method_60655(TrikiValsCreatures.MOD_ID, "dracopez_fins");
    public static final DracoPezFinsTintSource INSTANCE = new DracoPezFinsTintSource();
    public static final MapCodec<DracoPezFinsTintSource> CODEC = MapCodec.unit(INSTANCE);

    private static boolean registered = false;

    /** Safe to call more than once (client init and datagen). */
    public static void register() {
        if (!registered) {
            registered = true;
            class_10402.field_55235.method_65325(ID, CODEC);
        }
    }

    @Override
    public int method_65389(class_1799 stack, @Nullable class_638 world, @Nullable class_1309 user) {
        class_9279 data = stack.method_58695(class_9334.field_49610, class_9279.field_49302);
        int colorIndex = data.method_57461().method_68083("FinColor", class_1767.field_7952.method_7789());
        return class_9848.method_61334(class_1767.method_7791(colorIndex).method_7787());
    }

    @Override
    public MapCodec<DracoPezFinsTintSource> method_65387() {
        return CODEC;
    }
}
