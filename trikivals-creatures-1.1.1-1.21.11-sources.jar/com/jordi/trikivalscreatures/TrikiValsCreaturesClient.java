package com.jordi.trikivalscreatures;

import com.jordi.trikivalscreatures.client.tint.DracoPezFinsTintSource;
import com.jordi.trikivalscreatures.datagen.properties.PejelagartoVariantProperty;
import com.jordi.trikivalscreatures.entity.dracopez.render.DracoPezModel;
import com.jordi.trikivalscreatures.entity.dracopez.render.DracoPezRenderer;
import com.jordi.trikivalscreatures.entity.ModEntities;
import com.jordi.trikivalscreatures.entity.palgaster.render.PalgasterRenderer;
import com.jordi.trikivalscreatures.entity.client.ModModelLayers;
import com.jordi.trikivalscreatures.entity.pejelagarto.render.PejelagartoModel;
import com.jordi.trikivalscreatures.entity.pejelagarto.render.PejelagartoRenderer;
import com.jordi.trikivalscreatures.entity.pejelagarto.spit.PejelagartoSpitEntityRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.class_10493;
import net.minecraft.class_2960;
import net.minecraft.class_5619;

public class TrikiValsCreaturesClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
        class_10493.field_55421.method_65325(class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto_variant"), PejelagartoVariantProperty.TYPE);

        class_5619.method_32173(ModEntities.PEJELAGARTO, PejelagartoRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(ModModelLayers.PEJELAGARTO, PejelagartoModel::getTexturedModelData);

        class_5619.method_32173(ModEntities.PEJELAGARTO_SPIT, PejelagartoSpitEntityRenderer::new);

        DracoPezFinsTintSource.register();
        class_5619.method_32173(ModEntities.DRACOPEZ, DracoPezRenderer::new);
        EntityModelLayerRegistry.registerModelLayer(DracoPezModel.DRACOPEZ, DracoPezModel::getTexturedModelData);

        class_5619.method_32173(ModEntities.PALGASTER, PalgasterRenderer::new);
    }
}