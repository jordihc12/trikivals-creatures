package com.jordi.trikivalscreatures.entity.palgaster.render;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.palgaster.PalgasterCoat;
import com.jordi.trikivalscreatures.entity.palgaster.PalgasterEntity;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4608;
import net.minecraft.class_5617;
import net.minecraft.class_7833;
import net.minecraft.class_897;
import org.joml.Quaternionf;

import java.util.EnumMap;
import java.util.Map;

/**
 * Draws the Palgaster mesh (exported from Palgaster.bbmodel) directly with its bones and animations.
 * The mesh is loaded once and shared, so many Palgasters only cost the vertex upload each frame.
 */
@Environment(EnvType.CLIENT)
public class PalgasterRenderer extends class_897<PalgasterEntity, PalgasterRenderState> {
    private static final Map<PalgasterCoat, class_2960> TEXTURES = new EnumMap<>(PalgasterCoat.class);
    private static final class_2960 SADDLE_TEXTURE =
            class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/palgaster/palgaster_saddle.png");

    static {
        for (PalgasterCoat coat : PalgasterCoat.values()) {
            TEXTURES.put(coat, class_2960.method_60655(TrikiValsCreatures.MOD_ID,
                    "textures/entity/palgaster/palgaster_" + coat.getId() + ".png"));
        }
    }

    public PalgasterRenderer(class_5617.class_5618 context) {
        super(context);
        this.field_4673 = 0.9f;
        PalgasterMesh.get();
    }

    @Override
    public PalgasterRenderState method_55269() {
        return new PalgasterRenderState();
    }

    @Override
    public void updateRenderState(PalgasterEntity entity, PalgasterRenderState state, float tickDelta) {
        super.method_62354(entity, state, tickDelta);
        state.bodyYaw = class_3532.method_17821(tickDelta, entity.field_6220, entity.field_6283);
        state.coat = entity.getCoat();
        state.saddled = entity.method_66672();
        state.hurt = entity.field_6235 > 0 || entity.field_6213 > 0;
        state.animation = entity.getClientAnimation();
        state.animationTime = entity.getClientAnimationTime(tickDelta);
        state.deathTime = entity.field_6213 > 0 ? entity.field_6213 + tickDelta : 0f;
    }

    @Override
    public void render(PalgasterRenderState state, class_4587 matrices, class_11659 queue,
                       class_12075 cameraState) {
        PalgasterMesh mesh = PalgasterMesh.get();
        int boneCount = mesh.bones.size();
        if (boneCount == 0) {
            return;
        }

        // Animated bone transforms (rotation in degrees + position offset, Blockbench pixels)
        float[] pose = new float[boneCount * 6];
        PalgasterMesh.Anim anim = mesh.anims.get(state.animation);
        if (anim != null) {
            float t = anim.loop ? state.animationTime % anim.length : Math.min(state.animationTime, anim.length);
            float x = t / anim.length * (anim.samples - 1);
            int i0 = class_3532.method_15340((int) Math.floor(x), 0, anim.samples - 1);
            int i1 = Math.min(i0 + 1, anim.samples - 1);
            float f = x - i0;
            for (int b = 0; b < boneCount; b++) {
                float[] track = anim.tracks[b];
                if (track == null) continue;
                for (int c = 0; c < 6; c++) {
                    pose[b * 6 + c] = class_3532.method_16439(f, track[i0 * 6 + c], track[i1 * 6 + c]);
                }
            }
        }

        int light = state.field_61820;
        int overlay = class_4608.method_23624(0.0f, state.hurt);
        class_1921 bodyLayer = class_12249.method_75994(TEXTURES.get(state.coat));
        class_1921 saddleLayer = class_12249.method_75994(SADDLE_TEXTURE);

        matrices.method_22903();
        matrices.method_22907(class_7833.field_40716.rotationDegrees(180.0f - state.bodyYaw));
        if (state.deathTime > 0) {
            // Fall on its side like vanilla mobs
            float d = Math.min(1.0f, class_3532.method_15355((state.deathTime - 1.0f) / 20.0f * 1.6f));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(d * 90.0f));
        }
        matrices.method_22905(1.0f / 16.0f, 1.0f / 16.0f, 1.0f / 16.0f);

        int[] chain = new int[boneCount];
        for (PalgasterMesh.Part part : mesh.parts) {
            if (part.saddle && !state.saddled) continue;

            int depth = 0;
            for (int b = part.bone; b >= 0; b = mesh.bones.get(b).parent) {
                chain[depth++] = b;
            }
            matrices.method_22903();
            for (int k = depth - 1; k >= 0; k--) {
                int b = chain[k];
                PalgasterMesh.Bone bone = mesh.bones.get(b);
                int o = b * 6;
                matrices.method_46416(bone.px + pose[o + 3], bone.py + pose[o + 4], bone.pz + pose[o + 5]);
                if (pose[o] != 0 || pose[o + 1] != 0 || pose[o + 2] != 0) {
                    matrices.method_22907(new Quaternionf().rotateZ(pose[o + 2] * class_3532.field_29847)
                            .rotateY(pose[o + 1] * class_3532.field_29847)
                            .rotateX(pose[o] * class_3532.field_29847));
                }
                matrices.method_46416(-bone.px, -bone.py, -bone.pz);
            }

            final float[] data = part.data;
            queue.method_73483(matrices, part.saddle ? saddleLayer : bodyLayer,
                    (entry, consumer) -> emitTriangles(entry, consumer, data, light, overlay));
            matrices.method_22909();
        }
        matrices.method_22909();

        super.method_3936(state, matrices, queue, cameraState);
    }

    /** The entity layers use quads, so every triangle is sent as a quad with its last vertex repeated. */
    private static void emitTriangles(class_4587.class_4665 entry, class_4588 consumer, float[] d, int light, int overlay) {
        for (int i = 0; i < d.length; i += 24) {
            vertex(entry, consumer, d, i, light, overlay);
            vertex(entry, consumer, d, i + 8, light, overlay);
            vertex(entry, consumer, d, i + 16, light, overlay);
            vertex(entry, consumer, d, i + 16, light, overlay);
        }
    }

    private static void vertex(class_4587.class_4665 entry, class_4588 consumer, float[] d, int i, int light, int overlay) {
        consumer.method_56824(entry, d[i], d[i + 1], d[i + 2])
                .method_39415(-1)
                .method_22913(d[i + 3], d[i + 4])
                .method_22922(overlay)
                .method_60803(light)
                .method_60831(entry, d[i + 5], d[i + 6], d[i + 7]);
    }
}
