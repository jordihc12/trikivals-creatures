package com.jordi.trikivalscreatures.entity.palgaster.render;

import com.jordi.trikivalscreatures.entity.palgaster.PalgasterCoat;
import net.minecraft.class_10017;

public class PalgasterRenderState extends class_10017 {
    public float bodyYaw;
    public PalgasterCoat coat = PalgasterCoat.BLANCO;
    public boolean saddled;
    public boolean hurt;
    public String animation = "idle";
    public float animationTime;
    public float deathTime;
}
