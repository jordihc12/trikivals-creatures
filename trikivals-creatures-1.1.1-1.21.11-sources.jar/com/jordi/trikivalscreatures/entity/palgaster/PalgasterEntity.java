package com.jordi.trikivalscreatures.entity.palgaster;

import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1266;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1315;
import net.minecraft.class_1496;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3486;
import net.minecraft.class_3489;
import net.minecraft.class_3730;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * Palgaster: big feathered mount (test version).
 * - Behaves like a horse: saddle it (right click with a saddle, or sneak + right click to open its inventory)
 *   and ride it.
 * - No taming mechanic yet: it spawns already tamed.
 * - Each Palgaster has a coat colour (like horses); the beak and crest are always yellow.
 */
public class PalgasterEntity extends class_1496 {
    private static final class_2940<Integer> COAT =
            class_2945.method_12791(PalgasterEntity.class, class_2943.field_13327);

    // ---- client-side animation state (only used by the renderer) ----
    private float clientSpeed;
    private String clientAnimation = "idle";
    private int clientAnimationStart;

    public PalgasterEntity(class_1299<? extends class_1496> entityType, class_1937 world) {
        super(entityType, world);
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (this.method_73183().method_8608()) {
            double dx = this.method_23317() - this.field_6014;
            double dz = this.method_23321() - this.field_5969;
            float speed = (float) Math.sqrt(dx * dx + dz * dz);
            this.clientSpeed += (speed - this.clientSpeed) * 0.35f;

            String next;
            if (this.method_5799() && this.method_5861(class_3486.field_15517) > 0.6) {
                next = "swim";
            } else if (this.clientSpeed > 0.17f) {
                next = "run";
            } else if (this.clientSpeed > 0.015f) {
                next = "walk";
            } else {
                next = "idle";
            }
            if (!next.equals(this.clientAnimation)) {
                this.clientAnimation = next;
                this.clientAnimationStart = this.field_6012;
            }
        }
    }

    public String getClientAnimation() {
        return clientAnimation;
    }

    /** Seconds since the current animation started. */
    public float getClientAnimationTime(float tickDelta) {
        return (this.field_6012 - this.clientAnimationStart + tickDelta) / 20.0f;
    }

    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31573(class_3489.field_49938);
    }

    public static class_5132.class_5133 createPalgasterAttributes() {
        return class_1496.method_26899()
                .method_26868(class_5134.field_23716, 34.0)
                .method_26868(class_5134.field_23719, 0.26)
                .method_26868(class_5134.field_23728, 0.8)
                .method_26868(class_5134.field_47761, 1.1);
    }

    // Fixed stats (no random horse stats for now)
    @Override
    protected void method_6001(class_5819 random) {
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason,
                                 @Nullable class_1315 entityData) {
        this.setCoat(PalgasterCoat.values()[world.method_8409().method_43048(PalgasterCoat.values().length)]);
        // Test version: already tamed so it can be saddled and ridden straight away
        this.method_6766(true);
        return super.method_5943(world, difficulty, spawnReason, entityData);
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(COAT, 0);
    }

    @Override
    protected void method_5652(class_11372 view) {
        super.method_5652(view);
        view.method_71465("Coat", this.getCoat().ordinal());
    }

    @Override
    protected void method_5749(class_11368 view) {
        super.method_5749(view);
        this.setCoat(PalgasterCoat.byIndex(view.method_71424("Coat", 0)));
    }

    public PalgasterCoat getCoat() {
        return PalgasterCoat.byIndex(this.field_6011.method_12789(COAT));
    }

    public void setCoat(PalgasterCoat coat) {
        this.field_6011.method_12778(COAT, coat.ordinal());
    }

    @Override
    public @Nullable class_1296 method_5613(class_3218 world, class_1296 entity) {
        return null;
    }

    @Override
    protected class_3414 method_5994() {
        return class_3417.field_14947;
    }

    @Override
    protected class_3414 method_6011(class_1282 source) {
        return class_3417.field_14923;
    }

    @Override
    protected class_3414 method_6002() {
        return class_3417.field_15166;
    }

    @Override
    protected @Nullable class_3414 method_6747() {
        return class_3417.field_15043;
    }
}
