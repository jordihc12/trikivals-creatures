package com.jordi.trikivalscreatures.entity.dracopez;

import com.jordi.trikivalscreatures.entity.ModEntities;
import com.jordi.trikivalscreatures.entity.dracopez.ai.DracoPezIntelligenceManager;
import com.jordi.trikivalscreatures.entity.dracopez.ai.DracoPezMoveControl;
import com.jordi.trikivalscreatures.entity.dracopez.anims.DracoPezAnimatorManager;
import com.jordi.trikivalscreatures.entity.goals.IntelligenceManager;
import com.jordi.trikivalscreatures.items.ModItems;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1315;
import net.minecraft.class_1324;
import net.minecraft.class_1408;
import net.minecraft.class_1412;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1767;
import net.minecraft.class_1769;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_4538;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5425;
import net.minecraft.class_5761;
import net.minecraft.class_5819;
import net.minecraft.class_7;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import net.minecraft.entity.*;
import org.jetbrains.annotations.Nullable;

/**
 * DracoPez: pequeño dragón de agua, pasivo.
 * - Solo vive en el agua. Fuera de ella da saltos como un pez y acaba muriendo.
 * - Huye a toda velocidad de los jugadores, salvo si llevan bayas luminosas: entonces se acerca,
 *   rodea al jugador un par de veces y se queda quieto curioseando.
 * - Se reproduce con bayas luminosas.
 * - Se le pueden teñir las aletas con tinte (como la lana de las ovejas).
 * - Se puede coger con un cubo de agua (guarda tamaño y color de aletas).
 * - Cada ejemplar tiene un tamaño distinto: de 1,5 a 2 bloques de largo (las crías, 0,75).
 */
public class DracoPezEntity extends class_1429 implements class_5761 {

// ANIMATION VARIABLES
    private final DracoPezAnimatorManager animationManager = new DracoPezAnimatorManager();

// DATA TRACKER VARIABLES
    private static final class_2940<Integer> FIN_COLOR =
            class_2945.method_12791(DracoPezEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> FROM_BUCKET =
            class_2945.method_12791(DracoPezEntity.class, class_2943.field_13323);

// SIZE LOGIC
    // Length of the model at scale 1 (33 model pixels = 2.0625 blocks)
    public static final float MODEL_LENGTH_BLOCKS = 33.0F / 16.0F;
    public static final float MIN_LENGTH_BLOCKS = 1.5F;
    public static final float MAX_LENGTH_BLOCKS = 2.0F;
    public static final float BABY_LENGTH_BLOCKS = 0.75F;
    public static final float MIN_SCALE = MIN_LENGTH_BLOCKS / MODEL_LENGTH_BLOCKS;
    public static final float MAX_SCALE = MAX_LENGTH_BLOCKS / MODEL_LENGTH_BLOCKS;
    // Babies are born at 0.75 blocks and grow up to their adult size
    public static final float BABY_SCALE = BABY_LENGTH_BLOCKS / MODEL_LENGTH_BLOCKS;

    private float adultScale = MIN_SCALE;

// PANIC LOGIC (server side only)
    private int panicTicks = 0;
    @Nullable
    private class_1309 panicSource;

// AIR LOGIC (same as vanilla fish)
    private static final int MAX_AIR = 300;

    public static final float CURIOUS_RANGE = 12.0F;

// SWIM SPEEDS ("gears"). Multipliers passed to goals / move control. Blocks per second ~= 2 x multiplier:
// CALM ~1.2 blocks/s, CURIOUS (circling the player) ~1.6 blocks/s, FLEE ~4-5 blocks/s
    public static final double SPEED_CALM = 0.6;
    public static final double SPEED_CURIOUS = 0.8;
    public static final double SPEED_FLEE_SLOW = 2.0;
    public static final double SPEED_FLEE_FAST = 2.5;
    // After being hit: ~6 blocks/s for PANIC_TICKS
    public static final double SPEED_PANIC = 3.0;
    public static final int PANIC_TICKS = 100; // 5 seconds
    // Movement per tick above which the swim animation plays at double speed (fleeing)
    public static final double FAST_SWIM_THRESHOLD = 0.13;

    //region INITIALIZATION
    public DracoPezEntity(class_1299<? extends class_1429> entityType, class_1937 world) {
        super(entityType, world);
        this.method_5941(class_7.field_18, 0.0F);
        this.field_6207 = new DracoPezMoveControl(this);
    }

    public static class_5132.class_5133 createDracoPezAttributes() {
        return class_1429.method_26828()
                .method_26868(class_5134.field_23716, 10.0F)
                .method_26868(class_5134.field_23719, 1.0F)
                .method_26868(class_5134.field_52450, CURIOUS_RANGE);
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason,
                                 @Nullable class_1315 entityData) {
        class_5819 random = world.method_8409();
        this.adultScale = randomAdultScale(random);
        this.setFinColor(randomNaturalFinColor(random));

        class_1315 data = super.method_5943(world, difficulty, spawnReason, entityData);
        this.applyScaleForAge();
        return data;
    }

    public static boolean canSpawn(class_1299<DracoPezEntity> entity, class_1936 world, class_3730 spawnReason, class_2338 pos, class_5819 random) {
        return world.method_8316(pos).method_15767(class_3486.field_15517)
                && world.method_8316(pos.method_10074()).method_15767(class_3486.field_15517)
                && world.method_8320(pos.method_10084()).method_27852(class_2246.field_10382);
    }

    // Like axolotls/fish: water inside the hitbox must not block spawning
    @Override
    public boolean method_5957(class_4538 world) {
        return world.method_8606(this);
    }

    // AnimalEntity prefers bright grass blocks; in water every position is equally good (also dark lush caves)
    @Override
    public float method_6144(class_2338 pos, class_4538 world) {
        return 0.0F;
    }
//endregion

//region DATA TRACKER
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(FIN_COLOR, class_1767.field_7952.method_7789());
        builder.method_56912(FROM_BUCKET, false);
    }

    @Override
    protected void method_5652(class_11372 view) {
        super.method_5652(view);
        view.method_71465("FinColor", this.getFinColor().method_7789());
        view.method_71464("AdultScale", this.adultScale);
        view.method_71472("FromBucket", this.method_6453());
    }

    @Override
    protected void method_5749(class_11368 view) {
        super.method_5749(view);
        this.setFinColor(class_1767.method_7791(view.method_71424("FinColor", class_1767.field_7952.method_7789())));
        this.adultScale = clampAdultScale(view.method_71423("AdultScale", MIN_SCALE));
        this.method_6454(view.method_71433("FromBucket", false));
        this.applyScaleForAge();
    }
//endregion

//region FIN COLOR
    public class_1767 getFinColor() {
        return class_1767.method_7791(this.field_6011.method_12789(FIN_COLOR));
    }

    public void setFinColor(class_1767 color) {
        this.field_6011.method_12778(FIN_COLOR, color.method_7789());
    }

    private static class_1767 randomNaturalFinColor(class_5819 random) {
        // Like guppies: lots of colors. White is a bit more common.
        if (random.method_43048(4) == 0) {
            return class_1767.field_7952;
        }
        class_1767[] colors = class_1767.values();
        return colors[random.method_43048(colors.length)];
    }
//endregion

//region SIZE
    private static float clampAdultScale(float scale) {
        return class_3532.method_15363(scale, MIN_SCALE, MAX_SCALE);
    }

    /**
     * Small (1.5-1.65 blocks) 40%, medium (1.65-1.85 blocks) 40%, large (1.85-2 blocks) 20%.
     */
    private static float randomAdultScale(class_5819 random) {
        int roll = random.method_43048(10);
        float lengthBlocks;
        if (roll < 4) {
            lengthBlocks = class_3532.method_32750(random, 1.5F, 1.65F);
        } else if (roll < 8) {
            lengthBlocks = class_3532.method_32750(random, 1.65F, 1.85F);
        } else {
            lengthBlocks = class_3532.method_32750(random, 1.85F, 2.0F);
        }
        return clampAdultScale(lengthBlocks / MODEL_LENGTH_BLOCKS);
    }

    public float getAdultScale() {
        return this.adultScale;
    }

    /** Length in blocks of this DracoPez once it's an adult. */
    public float getAdultLengthBlocks() {
        return this.adultScale * MODEL_LENGTH_BLOCKS;
    }

    private void setBodyScale(float scale) {
        class_1324 scaleAttr = this.method_5996(class_5134.field_47760);
        if (scaleAttr != null) {
            scaleAttr.method_6192(scale);
        }
    }

    private void applyScaleForAge() {
        this.setBodyScale(this.method_6109() ? BABY_SCALE : this.adultScale);
    }

    // Babies don't use the vanilla 0.5 multiplier: they use BABY_SCALE (0.75 blocks long)
    @Override
    public float method_17825() {
        return 1.0F;
    }

    @Override
    protected void method_5619() {
        super.method_5619();
        this.applyScaleForAge();
    }
//endregion

//region ANIMATIONS
    public final DracoPezAnimatorManager getAnimationManager() {
        return animationManager;
    }
//endregion

//region UPDATE
    @Override
    public void method_5773() {
        super.method_5773();

        if (this.method_73183().method_8608()) {
            animationManager.updateActiveAnimation(this);
            animationManager.updateAnimations(this.field_6012);
        }
        else if (this.panicTicks > 0) {
            this.panicTicks--;
            if (this.panicTicks == 0) {
                this.panicSource = null;
            }
        }
    }

    // When hit by someone, dart away from them at full speed for a few seconds
    @Override
    public boolean method_64397(class_3218 world, class_1282 source, float amount) {
        boolean damaged = super.method_64397(world, source, amount);
        if (damaged && this.method_5805()) {
            this.panicTicks = PANIC_TICKS;
            if (source.method_5529() instanceof class_1309 attacker) {
                this.panicSource = attacker;
            }
        }
        return damaged;
    }

    public boolean isInPanic() {
        return this.panicTicks > 0;
    }

    public @Nullable class_1309 getPanicSource() {
        return this.panicSource;
    }

    @Override
    public void method_5670() {
        int air = this.method_5669();
        super.method_5670();
        if (!this.method_5987() && this.method_73183() instanceof class_3218 serverWorld) {
            this.tickWaterBreathingAir(serverWorld, air);
        }
    }

    // Same mechanic as vanilla fish: out of water it loses air and then takes damage until it dies
    private void tickWaterBreathingAir(class_3218 world, int air) {
        if (this.method_5805() && !this.method_5799()) {
            this.method_5855(air - 1);
            if (this.method_5669() == -20) {
                this.method_5855(0);
                this.method_64397(world, this.method_48923().method_48834(), 2.0F);
            }
        } else {
            this.method_5855(MAX_AIR);
        }
    }

    @Override
    public void method_6007() {
        // Flop around like a fish when on land
        if (!this.method_5799() && this.method_24828() && this.field_5992) {
            this.method_18799(this.method_18798().method_1031(
                    (this.field_5974.method_43057() * 2.0F - 1.0F) * 0.05F,
                    0.4F,
                    (this.field_5974.method_43057() * 2.0F - 1.0F) * 0.05F));
            this.method_24830(false);
            this.field_64356 = true;
            this.method_5783(this.getFlopSound(), this.method_6107(), this.method_6017());
        }

        super.method_6007();
    }

    @Override
    public void method_6091(class_243 movementInput) {
        if (this.method_66247() && this.method_5799()) {
            // Push forward (in the direction it is facing) proportionally to the movement speed.
            // With the 0.9 water drag the top speed is ~0.1 x speed blocks/tick (2 x speed blocks/s)
            float speed = this.method_6029();
            if (speed > 1.0E-3F) {
                this.method_5724(speed * 0.01F, new class_243(0.0, 0.0, 1.0));
            }
            this.method_5784(class_1313.field_6308, this.method_18798());
            this.method_18799(this.method_18798().method_1021(0.9));
        } else {
            super.method_6091(movementInput);
        }
    }

    @Override
    public boolean method_6094() {
        return true;
    }

    @Override
    public boolean method_5675() {
        return false;
    }

    @Override
    public int method_5748() {
        return MAX_AIR;
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);

        // Dye the fins (like sheep wool)
        if (itemStack.method_7909() instanceof class_1769 dyeItem) {
            class_1767 color = dyeItem.method_7802();
            if (this.method_5805() && color != this.getFinColor()) {
                if (!this.method_73183().method_8608()) {
                    this.setFinColor(color);
                    itemStack.method_57008(1, player);
                    this.method_73183().method_43129(null, this, class_3417.field_28391,
                            player.method_5634(), 1.0F, 1.0F);
                }
                return class_1269.field_5812;
            }
        }

        // Water bucket -> DracoPez bucket. If not, breeding with glow berries (handled by AnimalEntity)
        return class_5761.method_35169(player, hand, this).orElseGet(() -> super.method_5992(player, hand));
    }

    /** True if this player makes the DracoPez curious instead of scared. */
    public static boolean isAttractedBy(class_1309 entity) {
        return entity instanceof class_1657 player && !player.method_7325() && player.method_24518(class_1802.field_28659);
    }
//endregion

//region BUCKET
    @Override
    public boolean method_6453() {
        return this.field_6011.method_12789(FROM_BUCKET);
    }

    @Override
    public void method_6454(boolean fromBucket) {
        this.field_6011.method_12778(FROM_BUCKET, fromBucket);
    }

    @Override
    public void method_6455(class_1799 stack) {
        class_5761.method_35167(this, stack);
        class_9279.method_57452(class_9334.field_49610, stack, nbt -> {
            nbt.method_10569("FinColor", this.getFinColor().method_7789());
            nbt.method_10548("AdultScale", this.adultScale);
            nbt.method_10569("Age", this.method_5618());
        });
    }

    @Override
    public void method_35170(class_2487 nbt) {
        class_5761.method_35168(this, nbt);
        // Empty buckets (creative tab, /give) keep the random color and size picked when spawning
        if (nbt.method_10545("FinColor")) {
            this.setFinColor(class_1767.method_7791(nbt.method_68083("FinColor", class_1767.field_7952.method_7789())));
        }
        if (nbt.method_10545("AdultScale")) {
            this.adultScale = clampAdultScale(nbt.method_66563("AdultScale", this.adultScale));
        }
        if (nbt.method_10545("Age")) {
            this.method_5614(nbt.method_68083("Age", 0));
        }
        this.applyScaleForAge();
    }

    @Override
    public class_1799 method_6452() {
        return new class_1799(ModItems.DRACOPEZ_BUCKET);
    }

    @Override
    public class_3414 method_35171() {
        return class_3417.field_14568;
    }

    @Override
    public boolean method_17326() {
        return super.method_17326() || this.method_6453();
    }

    @Override
    public boolean method_5974(double distanceSquared) {
        return !this.method_6453() && !this.method_16914();
    }
//endregion

//region BREEDING
    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(class_1802.field_28659);
    }

    @Override
    public @Nullable class_1296 method_5613(class_3218 world, class_1296 entity) {
        DracoPezEntity baby = ModEntities.DRACOPEZ.method_5883(world, class_3730.field_16466);
        if (baby != null) {
            class_1767 babyColor = this.getFinColor();
            float babyAdultScale = this.adultScale;

            if (entity instanceof DracoPezEntity mate) {
                // Fin colors are mixed like sheep wool
                babyColor = class_1767.method_65355(world, this.getFinColor(), mate.getFinColor());
                // Size somewhere between both parents, with a little variation
                float t = this.field_5974.method_43057();
                babyAdultScale = class_3532.method_16439(t, this.adultScale, mate.adultScale)
                        + (this.field_5974.method_43057() - 0.5F) * 0.1F;
            }

            baby.setFinColor(babyColor);
            baby.adultScale = clampAdultScale(babyAdultScale);
            baby.setBodyScale(BABY_SCALE);
            baby.method_5971();
        }
        return baby;
    }
//endregion

//region SOUNDS
    @Override
    protected @Nullable class_3414 method_5994() {
        return class_3417.field_15085;
    }

    @Override
    protected @Nullable class_3414 method_6011(class_1282 source) {
        return class_3417.field_14985;
    }

    @Override
    protected @Nullable class_3414 method_6002() {
        return class_3417.field_15201;
    }

    // Splashes while swimming near the surface, like vanilla fish
    @Override
    protected class_3414 method_5737() {
        return class_3417.field_14591;
    }

    // Sound of each jump when it is out of the water (same as tropical fish)
    protected class_3414 getFlopSound() {
        return class_3417.field_14878;
    }
//endregion

//region INTELLIGENCE
    @Override
    protected class_1408 method_5965(class_1937 world) {
        return new class_1412(this, world);
    }

    @Override
    protected void method_5959() {
        IntelligenceManager.setGoals(this, DracoPezIntelligenceManager::new);
    }
//endregion
}
