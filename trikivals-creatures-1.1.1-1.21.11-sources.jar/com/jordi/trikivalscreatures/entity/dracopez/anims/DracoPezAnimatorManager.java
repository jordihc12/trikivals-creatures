package com.jordi.trikivalscreatures.entity.dracopez.anims;

import com.jordi.trikivalscreatures.entity.anims.AnimationManager;
import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;

public class DracoPezAnimatorManager extends AnimationManager<DracoPezEntity, DracoPezAnimation> {

    public DracoPezAnimatorManager() {
        super(DracoPezAnimation.class, DracoPezAnimation.IDLE_WATER);
    }

    @Override
    public DracoPezAnimation getActiveAnimationPriv(DracoPezEntity entity) {
        if (!entity.method_5799()) {
            return DracoPezAnimation.FLOP;
        }
        // Position change since last tick (works on the client for every entity)
        double dx = entity.method_23317() - entity.field_6014;
        double dy = entity.method_23318() - entity.field_6036;
        double dz = entity.method_23321() - entity.field_5969;
        double moved = dx * dx + dy * dy + dz * dz;
        if (moved > DracoPezEntity.FAST_SWIM_THRESHOLD * DracoPezEntity.FAST_SWIM_THRESHOLD) {
            return DracoPezAnimation.SWIM_FAST;
        }
        else if (moved > 0.0004) {
            return DracoPezAnimation.SWIM;
        }
        else {
            return DracoPezAnimation.IDLE_WATER;
        }
    }
}
