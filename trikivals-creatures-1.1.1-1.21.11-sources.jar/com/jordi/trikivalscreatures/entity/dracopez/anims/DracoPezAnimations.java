package com.jordi.trikivalscreatures.entity.dracopez.anims;

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;
import net.minecraft.client.render.entity.animation.*;

/**
 * Generated from DracoPez.bbmodel (animations dracopez_swim, dracopez_idle_water, dracopez_flop).
 * The swim animation is an undulating wave that travels from the head to the tail fan,
 * with the two pairs of wings flapping out of phase.
 */
public class DracoPezAnimations {
    public static final class_7184 DRACOPEZ_SWIM = class_7184.class_7185.method_41818(1.0000F).method_41817()
                .method_41820("ala_13", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -28.519F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 0.000F, -9.902F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 0.000F, 14.515F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 30.429F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 0.000F, 28.519F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 0.000F, 9.902F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, -14.515F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 0.000F, -30.429F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 0.000F, -28.519F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_14", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 28.519F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 0.000F, 9.902F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 0.000F, -14.515F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -30.429F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 0.000F, -28.519F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 0.000F, -9.902F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, 14.515F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 0.000F, 30.429F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 0.000F, 28.519F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_5", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 0.000F, -22.627F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 0.000F, -32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -22.627F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 0.000F, -0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 0.000F, 22.627F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, 32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 0.000F, 22.627F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_6", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 0.000F, 22.627F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 0.000F, 32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 22.627F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 0.000F, -22.627F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, -32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 0.000F, -22.627F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 0.000F, -0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(2.364F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(7.076F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(7.643F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(3.732F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(-2.364F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(-7.076F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-7.643F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(-3.732F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(2.364F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 10.307F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 0.000F, 15.942F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 0.000F, 12.237F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 1.365F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 0.000F, -10.307F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 0.000F, -15.942F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, -12.237F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 0.000F, -1.365F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 0.000F, 10.307F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -10.307F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 0.000F, -15.942F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 0.000F, -12.237F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -1.365F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 0.000F, 10.307F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 0.000F, 15.942F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, 12.237F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 0.000F, 1.365F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 0.000F, -10.307F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_4", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, -15.523F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, -18.966F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, -11.299F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 2.987F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, 15.523F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, 18.966F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 11.299F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, -2.987F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, -15.523F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_5", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 15.523F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(0.000F, 18.966F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(0.000F, 11.299F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, -2.987F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, -15.523F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(0.000F, -18.966F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, -11.299F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(0.000F, 2.987F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.000F, 15.523F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("dracopez", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.876F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(2.085F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(2.072F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.846F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(-0.876F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(-2.085F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-2.072F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(-0.846F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(0.876F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-4.230F, -1.381F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(-5.365F, -0.405F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(-3.357F, 0.808F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.617F, 1.548F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(4.230F, 1.381F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(5.365F, 0.405F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(3.357F, -0.808F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(-0.617F, -1.548F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(-4.230F, -1.381F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 3.728F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(6.364F, 3.661F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(9.000F, 1.449F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(6.364F, -1.611F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(0.000F, -3.728F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(-6.364F, -3.661F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-9.000F, -1.449F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(-6.364F, 1.611F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(-0.000F, 3.728F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-7.050F, 1.182F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(-1.029F, 3.538F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(5.594F, 3.821F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(8.941F, 1.866F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(7.050F, -1.182F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(1.029F, -3.538F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-5.594F, -3.821F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(-8.941F, -1.866F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(-7.050F, 1.182F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-8.765F, -2.259F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(-7.643F, 0.737F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(-2.045F, 3.301F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(4.752F, 3.931F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(8.765F, 2.259F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(7.643F, -0.737F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(2.045F, -3.301F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(-4.752F, -3.931F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(-8.765F, -2.259F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_4", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-3.846F, -3.990F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(-8.473F, -2.621F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(-8.137F, 0.283F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-3.034F, 3.021F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(3.846F, 3.990F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(8.473F, 2.621F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(8.137F, -0.283F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(3.034F, -3.021F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(-3.846F, -3.990F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_6", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(5.177F, -2.702F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(-3.758F, -3.996F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(-10.492F, -2.950F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-11.080F, -0.175F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(-5.177F, 2.702F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(3.758F, 3.996F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(10.492F, 2.950F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(11.080F, 0.175F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(5.177F, -2.702F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_9", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(7.169F, -2.702F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1250F, class_7187.method_41829(-5.203F, -3.996F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2500F, class_7187.method_41829(-14.527F, -2.950F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-15.342F, -0.175F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5000F, class_7187.method_41829(-7.169F, 2.702F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6250F, class_7187.method_41829(5.203F, 3.996F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(14.527F, 2.950F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.8750F, class_7187.method_41829(15.342F, 0.175F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.0000F, class_7187.method_41829(7.169F, -2.702F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41821();

    public static final class_7184 DRACOPEZ_IDLE_WATER = class_7184.class_7185.method_41818(3.0000F).method_41817()
                .method_41820("ala_13", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -10.694F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -3.713F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, 5.443F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 0.000F, 11.411F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 0.000F, 10.694F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 0.000F, 3.713F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 0.000F, -5.443F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 0.000F, -11.411F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 0.000F, -10.694F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_14", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 10.694F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 3.713F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, -5.443F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 0.000F, -11.411F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 0.000F, -10.694F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 0.000F, -3.713F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 0.000F, 5.443F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 0.000F, 11.411F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 0.000F, 10.694F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_5", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -8.485F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, -12.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 0.000F, -8.485F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 0.000F, -0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 0.000F, 8.485F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 0.000F, 12.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 0.000F, 8.485F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_6", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 8.485F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, 12.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 0.000F, 8.485F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 0.000F, -8.485F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 0.000F, -12.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 0.000F, -8.485F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 0.000F, -0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.887F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(2.653F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(2.866F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(1.400F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(-0.887F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(-2.653F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(-2.866F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(-1.400F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.887F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 3.865F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 5.978F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, 4.589F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 0.000F, 0.512F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 0.000F, -3.865F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 0.000F, -5.978F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 0.000F, -4.589F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 0.000F, -0.512F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 0.000F, 3.865F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -3.865F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -5.978F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 0.000F, -4.589F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 0.000F, -0.512F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 0.000F, 3.865F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 0.000F, 5.978F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 0.000F, 4.589F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 0.000F, 0.512F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 0.000F, -3.865F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_4", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, -5.821F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, -7.112F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, -4.237F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, 1.120F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, 5.821F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, 7.112F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, 4.237F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, -1.120F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, -5.821F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("aleta_5", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 5.821F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 7.112F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.000F, 4.237F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.000F, -1.120F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, -5.821F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.000F, -7.112F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.000F, -4.237F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(0.000F, 1.120F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.000F, 5.821F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("dracopez", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.389F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.927F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(0.921F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.376F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(-0.389F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(-0.927F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(-0.921F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(-0.376F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(0.389F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-1.880F, -0.863F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-2.384F, -0.253F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-1.492F, 0.505F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(0.274F, 0.967F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(1.880F, 0.863F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(2.384F, 0.253F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(1.492F, -0.505F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(-0.274F, -0.967F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(-1.880F, -0.863F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 2.330F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(2.828F, 2.288F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(4.000F, 0.906F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(2.828F, -1.007F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(0.000F, -2.330F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(-2.828F, -2.288F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(-4.000F, -0.906F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(-2.828F, 1.007F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(-0.000F, 2.330F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-3.133F, 0.739F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-0.457F, 2.211F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(2.486F, 2.388F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(3.974F, 1.166F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(3.133F, -0.739F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(0.457F, -2.211F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(-2.486F, -2.388F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(-3.974F, -1.166F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(-3.133F, 0.739F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-3.895F, -1.412F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-3.397F, 0.461F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-0.909F, 2.063F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(2.112F, 2.457F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(3.895F, 1.412F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(3.397F, -0.461F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(0.909F, -2.063F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(-2.112F, -2.457F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(-3.895F, -1.412F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_4", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-1.710F, -2.494F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-3.766F, -1.638F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-3.616F, 0.177F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(-1.348F, 1.888F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(1.710F, 2.494F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(3.766F, 1.638F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(3.616F, -0.177F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(1.348F, -1.888F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(-1.710F, -2.494F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_6", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(2.301F, -1.689F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-1.670F, -2.498F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-4.663F, -1.843F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(-4.924F, -0.109F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(-2.301F, 1.689F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(1.670F, 2.498F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(4.663F, 1.843F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(4.924F, 0.109F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(2.301F, -1.689F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_9", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(3.186F, -1.689F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-2.313F, -2.498F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.7500F, class_7187.method_41829(-6.457F, -1.843F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.1250F, class_7187.method_41829(-6.818F, -0.109F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.5000F, class_7187.method_41829(-3.186F, 1.689F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(1.8750F, class_7187.method_41829(2.313F, 2.498F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.2500F, class_7187.method_41829(6.457F, 1.843F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(2.6250F, class_7187.method_41829(6.818F, 0.109F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(3.0000F, class_7187.method_41829(3.186F, -1.689F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41821();

    public static final class_7184 DRACOPEZ_FLOP = class_7184.class_7185.method_41818(0.6000F).method_41817()
                .method_41820("ala_13", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 6.585F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(0.000F, 0.000F, 9.597F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.000F, 0.000F, 23.415F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(0.000F, 0.000F, 20.403F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(0.000F, 0.000F, 6.585F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 9.597F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.000F, 0.000F, 23.415F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(0.000F, 0.000F, 20.403F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(0.000F, 0.000F, 6.585F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_14", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -6.585F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(0.000F, 0.000F, -9.597F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.000F, 0.000F, -23.415F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(0.000F, 0.000F, -20.403F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(0.000F, 0.000F, -6.585F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -9.597F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.000F, 0.000F, -23.415F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(0.000F, 0.000F, -20.403F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(0.000F, 0.000F, -6.585F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_5", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, -20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(0.000F, 0.000F, -8.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.000F, 0.000F, -20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(0.000F, 0.000F, -32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(0.000F, 0.000F, -20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, -8.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.000F, 0.000F, -20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(0.000F, 0.000F, -32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(0.000F, 0.000F, -20.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("ala_6", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(0.000F, 0.000F, 8.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.000F, 0.000F, 20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(0.000F, 0.000F, 32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(0.000F, 0.000F, 20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 0.000F, 8.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.000F, 0.000F, 20.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(0.000F, 0.000F, 32.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(0.000F, 0.000F, 20.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, -11.596F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(0.000F, -17.934F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.000F, -13.767F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(0.000F, -1.535F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(0.000F, 11.596F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(0.000F, 17.934F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.000F, 13.767F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(0.000F, 1.535F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(0.000F, -11.596F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(20.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(35.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(20.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(5.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(20.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(35.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(20.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(5.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(20.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(4.000F, 15.556F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.000F, 22.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(-4.000F, 15.556F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(-0.000F, 0.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(4.000F, -15.556F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.000F, -22.000F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(-4.000F, -15.556F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(-0.000F, -0.000F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-3.366F, -14.173F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(2.161F, 1.876F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(3.366F, 16.827F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(-2.161F, 21.920F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(-3.366F, 14.173F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(2.161F, -1.876F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(3.366F, -16.827F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(-2.161F, -21.920F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(-3.366F, -14.173F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-3.637F, -21.680F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(-1.665F, -12.686F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(3.637F, 3.739F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(1.665F, 17.974F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(-3.637F, 21.680F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-1.665F, 12.686F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(3.637F, -3.739F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(1.665F, -17.974F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(-3.637F, -21.680F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_4", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(-0.564F, -18.991F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(-3.960F, -21.282F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(0.564F, -11.107F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(3.960F, 5.575F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(-0.564F, 18.991F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-3.960F, 21.282F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(0.564F, 11.107F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(3.960F, -5.575F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(-0.564F, -18.991F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_6", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(3.027F, -7.370F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(-2.615F, -19.869F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(-3.027F, -20.729F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(2.615F, -9.446F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(3.027F, 7.370F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(-2.615F, 19.869F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(-3.027F, 20.729F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(2.615F, 9.446F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(3.027F, -7.370F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41820("parte_9", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0000F, class_7187.method_41829(3.836F, 7.717F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.0750F, class_7187.method_41829(1.135F, -9.111F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.1500F, class_7187.method_41829(-3.836F, -20.602F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.2250F, class_7187.method_41829(-1.135F, -20.025F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3000F, class_7187.method_41829(3.836F, -7.717F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.3750F, class_7187.method_41829(1.135F, 9.111F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.4500F, class_7187.method_41829(-3.836F, 20.602F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.5250F, class_7187.method_41829(-1.135F, 20.025F, 0.000F), class_7179.class_7181.field_37885),
                        new class_7186(0.6000F, class_7187.method_41829(3.836F, 7.717F, 0.000F), class_7179.class_7181.field_37885)
                ))
                .method_41821();
}
