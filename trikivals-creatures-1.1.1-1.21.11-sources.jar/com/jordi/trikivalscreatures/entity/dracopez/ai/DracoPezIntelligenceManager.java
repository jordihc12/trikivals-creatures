package com.jordi.trikivalscreatures.entity.dracopez.ai;

import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import com.jordi.trikivalscreatures.entity.goals.IntelligenceManager;
import net.minecraft.class_1338;
import net.minecraft.class_1341;
import net.minecraft.class_1353;
import net.minecraft.class_1376;
import net.minecraft.class_1378;
import net.minecraft.class_1657;
import net.minecraft.entity.ai.goal.*;

public class DracoPezIntelligenceManager extends IntelligenceManager<DracoPezEntity> {
    public DracoPezIntelligenceManager(DracoPezEntity entity) {
        super(entity);
    }

    @Override
    public void setGoalsPriv() {
        // When hit: darts away from the attacker at full speed for a few seconds
        addGoal(new DracoPezPanicGoal(entity));
        // Runs away at full speed from any player that is NOT holding glow berries
        addGoal(new class_1338<>(entity, class_1657.class, 8.0F, DracoPezEntity.SPEED_FLEE_SLOW, DracoPezEntity.SPEED_FLEE_FAST,
                living -> !living.method_7325() && !DracoPezEntity.isAttractedBy(living)));
        // Breeding with glow berries
        addGoal(new class_1341(entity, DracoPezEntity.SPEED_CALM));
        // Holding glow berries: approaches slowly and keeps circling around the player
        addGoal(new DracoPezCuriousGoal(entity, DracoPezEntity.CURIOUS_RANGE));
        addGoal(new class_1353(entity, DracoPezEntity.SPEED_CALM * 1.1));
        // Calm random swimming like fish: picks a random spot, swims there, stops a few seconds, repeats
        addGoal(new class_1378(entity, DracoPezEntity.SPEED_CALM, 80));
        addGoal(new class_1376(entity));
    }
}
