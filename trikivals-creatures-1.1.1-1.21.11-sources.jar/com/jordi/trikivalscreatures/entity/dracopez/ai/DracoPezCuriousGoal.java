package com.jordi.trikivalscreatures.entity.dracopez.ai;

import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1352;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_3486;

/**
 * While a player holding glow berries is near, the DracoPez swims slowly towards them and then
 * keeps circling around them at CIRCLE_RADIUS blocks, for as long as they hold the berries.
 * When the player puts the berries away the goal stops and the flee goal (higher priority)
 * makes it dart away.
 * Movement goes straight through DracoPezMoveControl (no pathfinding), so it also works
 * when the player stands on the shore: it gets as close as the water allows.
 */
public class DracoPezCuriousGoal extends class_1352 {
    private enum Phase { APPROACH, CIRCLE }

    public static final double CIRCLE_RADIUS = 3.5;
    // How far ahead (radians) along the circle the swim target is placed: gives a smooth orbit
    private static final double LEAD_ANGLE = 0.6;

    private final DracoPezEntity dracoPez;
    private final double range;

    @Nullable
    private class_1657 player;
    private Phase phase;
    private double direction;
    private int ticks;

    public DracoPezCuriousGoal(DracoPezEntity dracoPez, double range) {
        this.dracoPez = dracoPez;
        this.range = range;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        if (!this.dracoPez.method_5799() || this.dracoPez.isInPanic()) {
            return false;
        }

        class_1657 closest = this.dracoPez.method_73183().method_18460(this.dracoPez, this.range);
        if (closest == null || !DracoPezEntity.isAttractedBy(closest)) {
            return false;
        }

        this.player = closest;
        return true;
    }

    @Override
    public boolean method_6266() {
        return this.player != null
                && this.player.method_5805()
                && this.dracoPez.method_5799()
                && DracoPezEntity.isAttractedBy(this.player)
                && this.dracoPez.method_5858(this.player) < (this.range + 4.0) * (this.range + 4.0);
    }

    @Override
    public void method_6269() {
        this.phase = Phase.APPROACH;
        this.direction = this.dracoPez.method_59922().method_43056() ? 1.0 : -1.0;
        this.ticks = 0;
        this.dracoPez.method_5942().method_6340();
    }

    @Override
    public void method_6270() {
        this.player = null;
        this.dracoPez.method_5942().method_6340();
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public void method_6268() {
        if (this.player == null) {
            return;
        }
        this.ticks++;

        double px = this.player.method_23317();
        double pz = this.player.method_23321();
        double dx = this.dracoPez.method_23317() - px;
        double dz = this.dracoPez.method_23321() - pz;
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        if (this.phase == Phase.APPROACH) {
            // Look at the player while coming closer
            this.dracoPez.method_5988().method_6226(this.player, 10.0F, (float) this.dracoPez.method_5978());

            if (horizontalDist <= CIRCLE_RADIUS + 0.75) {
                this.phase = Phase.CIRCLE;
            } else {
                double nx = horizontalDist < 1.0E-4 ? 1.0 : dx / horizontalDist;
                double nz = horizontalDist < 1.0E-4 ? 0.0 : dz / horizontalDist;
                double x = px + nx * CIRCLE_RADIUS;
                double z = pz + nz * CIRCLE_RADIUS;
                this.dracoPez.method_5962().method_6239(x, this.waterY(x, this.preferredY(), z), z, DracoPezEntity.SPEED_CALM);
            }
            return;
        }

        // CIRCLE: aim at a point a bit ahead along the circle, from where the DracoPez actually is
        double currentAngle = Math.atan2(dz, dx);
        double targetAngle = currentAngle + LEAD_ANGLE * this.direction;
        double x = px + Math.cos(targetAngle) * CIRCLE_RADIUS;
        double z = pz + Math.sin(targetAngle) * CIRCLE_RADIUS;
        // Gentle up and down wave while circling
        double y = this.waterY(x, this.preferredY() + Math.sin(this.ticks * 0.04) * 0.4, z);
        this.dracoPez.method_5962().method_6239(x, y, z, DracoPezEntity.SPEED_CURIOUS);
    }

    private double preferredY() {
        return this.player == null ? this.dracoPez.method_23318() : this.player.method_23320() - 0.8;
    }

    /** Keeps the target inside the water: if the desired height is not water, stays at the current height. */
    private double waterY(double x, double y, double z) {
        class_2338 pos = class_2338.method_49637(x, y, z);
        if (this.dracoPez.method_73183().method_8316(pos).method_15767(class_3486.field_15517)) {
            return y;
        }
        return this.dracoPez.method_23318();
    }
}
