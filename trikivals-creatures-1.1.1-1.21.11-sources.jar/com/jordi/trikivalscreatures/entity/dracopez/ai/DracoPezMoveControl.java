package com.jordi.trikivalscreatures.entity.dracopez.ai;

import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import net.minecraft.class_1335;
import net.minecraft.class_3532;
import net.minecraft.class_5134;

/**
 * Fish-like movement for the DracoPez.
 * Unlike the vanilla aquatic/fish controls it moves to any target set with moveTo(),
 * even without an active navigation path (used by the curious behaviour),
 * turns quickly towards the target (no dolphin-like orbits) and stops when it arrives.
 * The actual push is applied in DracoPezEntity.travel(): speed in blocks/s ~= 2 x speed multiplier.
 */
public class DracoPezMoveControl extends class_1335 {
    private static final double ARRIVE_DISTANCE = 0.6;
    private static final float MAX_TURN_PER_TICK = 20.0F;

    private final DracoPezEntity dracoPez;

    public DracoPezMoveControl(DracoPezEntity dracoPez) {
        super(dracoPez);
        this.dracoPez = dracoPez;
    }

    @Override
    public void method_6240() {
        if (this.field_6374 != class_1336.field_6378 || !this.dracoPez.method_5799()) {
            this.dracoPez.method_6125(class_3532.method_16439(0.25F, this.dracoPez.method_6029(), 0.0F));
            return;
        }

        double dx = this.field_6370 - this.dracoPez.method_23317();
        double dy = this.field_6369 - this.dracoPez.method_23318();
        double dz = this.field_6367 - this.dracoPez.method_23321();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist < ARRIVE_DISTANCE) {
            // Arrived: brake smoothly and wait for a new target
            this.field_6374 = class_1336.field_6377;
            this.dracoPez.method_6125(class_3532.method_16439(0.25F, this.dracoPez.method_6029(), 0.0F));
            return;
        }

        // Turn towards the target
        if (dx * dx + dz * dz > 1.0E-4) {
            float targetYaw = (float) (class_3532.method_15349(dz, dx) * 180.0F / (float) Math.PI) - 90.0F;
            this.dracoPez.method_36456(this.method_6238(this.dracoPez.method_36454(), targetYaw, MAX_TURN_PER_TICK));
            this.dracoPez.field_6283 = this.dracoPez.method_36454();
            this.dracoPez.field_6241 = this.dracoPez.method_36454();
        }

        // Pitch follows the vertical direction (used by the model)
        float targetPitch = (float) (-class_3532.method_15349(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0F / (float) Math.PI);
        this.dracoPez.method_36457(this.method_6238(this.dracoPez.method_36455(), class_3532.method_15363(targetPitch, -60.0F, 60.0F), 5.0F));

        // Accelerate / brake smoothly towards the requested speed; slow down when getting close
        float wanted = (float) (this.field_6372 * this.dracoPez.method_45325(class_5134.field_23719));
        if (dist < 2.0) {
            wanted *= (float) Math.max(0.35, dist / 2.0);
        }
        float speed = class_3532.method_16439(0.1F, this.dracoPez.method_6029(), wanted);
        this.dracoPez.method_6125(speed);

        // Vertical push with the same strength as the horizontal one (see DracoPezEntity.travel)
        this.dracoPez.method_18799(this.dracoPez.method_18798().method_1031(0.0, speed * 0.01 * (dy / dist), 0.0));
    }
}
