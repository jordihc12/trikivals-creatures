package com.jordi.trikivalscreatures.entity.dracopez.ai;

import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import org.jetbrains.annotations.Nullable;

import java.util.EnumSet;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_3486;

/**
 * After being hit, the DracoPez darts away at full speed for a few seconds,
 * always trying to get as far as possible from whoever hit it.
 * Every half second it picks a new escape point straight away from the attacker
 * (or the closest free direction if there is a wall), checking the way is clear water.
 */
public class DracoPezPanicGoal extends class_1352 {
    private static final double ESCAPE_DISTANCE = 10.0;
    private static final int REPICK_TICKS = 10;
    // Directions tried when straight away is blocked (degrees)
    private static final double[] ANGLE_OFFSETS = {0, 25, -25, 50, -50, 80, -80, 115, -115};

    private final DracoPezEntity dracoPez;
    private int repickCooldown;

    public DracoPezPanicGoal(DracoPezEntity dracoPez) {
        this.dracoPez = dracoPez;
        this.method_6265(EnumSet.of(class_4134.field_18405, class_4134.field_18406));
    }

    @Override
    public boolean method_6264() {
        return this.dracoPez.isInPanic() && this.dracoPez.method_5799();
    }

    @Override
    public boolean method_6266() {
        return this.method_6264();
    }

    @Override
    public void method_6269() {
        this.repickCooldown = 0;
        this.dracoPez.method_5942().method_6340();
    }

    @Override
    public void method_6270() {
        this.dracoPez.method_5942().method_6340();
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public void method_6268() {
        if (--this.repickCooldown > 0) {
            return;
        }
        this.repickCooldown = REPICK_TICKS;

        class_243 away = this.awayDirection(this.dracoPez.getPanicSource());
        class_243 target = this.findEscapePoint(away);
        if (target != null) {
            this.dracoPez.method_5962().method_6239(target.field_1352, target.field_1351, target.field_1350, DracoPezEntity.SPEED_PANIC);
        }
    }

    private class_243 awayDirection(@Nullable class_1309 attacker) {
        class_243 dir;
        if (attacker != null) {
            dir = new class_243(this.dracoPez.method_23317() - attacker.method_23317(), 0.0, this.dracoPez.method_23321() - attacker.method_23321());
        } else {
            dir = class_243.method_1030(0.0F, this.dracoPez.method_36454());
        }
        if (dir.method_1027() < 1.0E-4) {
            dir = new class_243(this.dracoPez.method_59922().method_43058() - 0.5, 0.0, this.dracoPez.method_59922().method_43058() - 0.5);
        }
        return dir.method_1029();
    }

    @Nullable
    private class_243 findEscapePoint(class_243 away) {
        class_243 from = new class_243(this.dracoPez.method_23317(), this.dracoPez.method_23318(), this.dracoPez.method_23321());
        // Dive a bit deeper while escaping
        double dy = -1.0 + this.dracoPez.method_59922().method_43058() * 0.5;

        for (double distance = ESCAPE_DISTANCE; distance >= 3.0; distance -= 3.5) {
            for (double offset : ANGLE_OFFSETS) {
                double rad = Math.toRadians(offset);
                double cos = Math.cos(rad);
                double sin = Math.sin(rad);
                class_243 dir = new class_243(away.field_1352 * cos - away.field_1350 * sin, 0.0, away.field_1352 * sin + away.field_1350 * cos);

                for (double y : new double[]{dy, 0.0}) {
                    class_243 target = from.method_1031(dir.field_1352 * distance, y, dir.field_1350 * distance);
                    if (this.isClearWater(from, target)) {
                        return target;
                    }
                }
            }
        }
        return null;
    }

    /** True if every block on the straight line between both points is water. */
    private boolean isClearWater(class_243 from, class_243 to) {
        class_1937 world = this.dracoPez.method_73183();
        int steps = (int) Math.ceil(from.method_1022(to));
        for (int i = 1; i <= steps; i++) {
            class_243 p = from.method_35590(to, (double) i / steps);
            if (!world.method_8316(class_2338.method_49638(p)).method_15767(class_3486.field_15517)) {
                return false;
            }
        }
        return true;
    }
}
