package com.jordi.trikivalscreatures.entity.dracopez.render;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import com.jordi.trikivalscreatures.entity.dracopez.anims.DracoPezAnimatorManager;
import net.minecraft.class_2960;
import net.minecraft.class_5617;
import net.minecraft.class_927;
import net.minecraft.class_9848;

public class DracoPezRenderer extends class_927<DracoPezEntity, DracoPezRenderState, DracoPezModel> {
    private static final class_2960 TEXTURE = class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/dracopez/dracopez.png");

    public DracoPezRenderer(class_5617.class_5618 context) {
        super(context, new DracoPezModel(context.method_32167(DracoPezModel.DRACOPEZ)), 0.35f);

        // Fins: white texture tinted with the dye color (like sheep wool)
        this.method_4046(new DracoPezFinsFeatureRenderer(this));
        // Bioluminescent eyes, spines and lateral line
        this.method_4046(new DracoPezGlowFeatureRenderer(this));
    }

    @Override
    public class_2960 getTexture(DracoPezRenderState state) {
        return TEXTURE;
    }

    @Override
    public DracoPezRenderState method_55269() {
        return new DracoPezRenderState();
    }

    @Override
    public void updateRenderState(DracoPezEntity entity, DracoPezRenderState state, float tickDelta) {
        super.method_62355(entity, state, tickDelta);

        DracoPezAnimatorManager manager = entity.getAnimationManager();
        var activeAnimation = manager.getActiveAnim();
        state.activeAnimation = activeAnimation;
        state.activeAnimationState.method_61401(manager.getAnimationStateFor(activeAnimation));

        state.finColor = class_9848.method_61334(entity.getFinColor().method_7787());
    }
}
