package com.jordi.trikivalscreatures.entity.dracopez.render;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.dracopez.anims.DracoPezAnimations;
import net.minecraft.class_11509;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

/**
 * Model generated from external_res/blockbench/DracoPez.bbmodel.
 * Texture: 128x128 image with 64x64 UV units (2 pixels per model pixel, same as the Pejelagarto).
 * Cubes with their own rotation in Blockbench are exported as child parts named "<group>_c<n>".
 */
public class DracoPezModel extends class_583<DracoPezRenderState> {
    public static final class_5601 DRACOPEZ = new class_5601(class_2960.method_60655(TrikiValsCreatures.MOD_ID, "dracopez"), "main");

    private final class_630 dracopez;
    private final class_630 head;

    //--- ANIMATIONS ---
    private final class_11509 swimAnimation;
    private final class_11509 idleWaterAnimation;
    private final class_11509 flopAnimation;

    public DracoPezModel(class_630 root) {
        super(root);
        this.dracopez = root.method_32086("dracopez");
        this.head = this.dracopez.method_32086("head");

        this.swimAnimation = DracoPezAnimations.DRACOPEZ_SWIM.method_71979(root);
        this.idleWaterAnimation = DracoPezAnimations.DRACOPEZ_IDLE_WATER.method_71979(root);
        this.flopAnimation = DracoPezAnimations.DRACOPEZ_FLOP.method_71979(root);
    }

    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();

        class_5610 dracopez = modelPartData.method_32117("dracopez", class_5606.method_32108(), class_5603.method_32090(-0.5000F, 20.7000F, -4.5745F));
        class_5610 head = dracopez.method_32117("head", class_5606.method_32108(), class_5603.method_32090(0.5000F, -0.7000F, -0.4255F));
        head.method_32117("head_c0", class_5606.method_32108().method_32101(48, 0).method_32098(-1.0000F, -1.7636F, -3.9922F, 3.0000F, 3.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.5000F, 0.7000F, 0.4255F, 0.0873F, 0.0000F, 0.0000F));
        head.method_32117("head_c7", class_5606.method_32108().method_32101(24, 42).method_32098(-0.2500F, -0.1000F, -2.4255F, 1.5000F, 1.0000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.5000F, 0.3000F, -3.1745F, 0.0873F, 0.0000F, 0.0000F));
        head.method_32117("head_c9", class_5606.method_32108().method_32101(32, 42).method_32098(-0.2500F, 0.0000F, -2.4255F, 0.5000F, 0.5000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(1.5000F, -0.7000F, -1.1745F, 0.0873F, 0.0000F, 0.0000F));
        head.method_32117("head_c10", class_5606.method_32108().method_32101(38, 42).method_32098(-0.2500F, 0.0000F, -2.4255F, 0.5000F, 0.5000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-1.5000F, -0.7000F, -1.1745F, 0.0873F, 0.0000F, 0.0000F));
        class_5610 aleta_1 = head.method_32117("aleta_1", class_5606.method_32108(), class_5603.method_32090(0.0000F, -0.7000F, -2.8745F));
        aleta_1.method_32117("aleta_1_c11", class_5606.method_32108().method_32101(29, 19).method_32098(-0.2500F, -0.4000F, -0.2255F, 0.5000F, 0.5000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.0000F, 0.0000F, 0.0000F, 1.2217F, 0.0000F, 0.0000F));
        aleta_1.method_32117("aleta_1_c12", class_5606.method_32108().method_32101(44, 42).method_32098(-0.0250F, -0.1500F, -0.2255F, 0.2500F, 0.2500F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, 0.0000F, 2.5000F, 0.8727F, 0.0000F, 0.0000F));
        aleta_1.method_32117("aleta_1_c13", class_5606.method_32108().method_32101(39, 19).method_32098(-0.0250F, -0.1500F, -3.2255F, 0.2500F, 0.2500F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -2.0000F, 2.5000F, 1.0472F, 0.0000F, 0.0000F));
        aleta_1.method_32117("aleta_1_c31", class_5606.method_32108().method_32101(0, 19).method_32098(-0.1600F, -1.9000F, -3.2255F, 0.0000F, 2.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.2000F, -1.8000F, 2.4000F, 1.2217F, 0.0000F, 0.0000F));
        aleta_1.method_32117("aleta_1_c32", class_5606.method_32108().method_32101(35, 37).method_32098(-0.1600F, -0.5000F, -3.2255F, 0.0000F, 1.6000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(0.2000F, -3.0000F, 3.6000F, 0.8290F, 0.0000F, 0.0000F));
        class_5610 aleta_2 = head.method_32117("aleta_2", class_5606.method_32108(), class_5603.method_32091(-1.3000F, 1.8000F, -2.0745F, 0.0000F, 0.0000F, -2.1380F));
        aleta_2.method_32117("aleta_2_c14", class_5606.method_32108().method_32101(49, 19).method_32098(-0.2500F, -0.4000F, -0.2255F, 0.5000F, 0.5000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.0000F, 0.0000F, 0.0000F, 1.2217F, 0.0000F, 0.0000F));
        aleta_2.method_32117("aleta_2_c15", class_5606.method_32108().method_32101(50, 42).method_32098(-0.0250F, -0.1500F, -0.2255F, 0.2500F, 0.2500F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, 0.0000F, 2.5000F, 0.8727F, 0.0000F, 0.0000F));
        aleta_2.method_32117("aleta_2_c16", class_5606.method_32108().method_32101(0, 26).method_32098(-0.0250F, -0.1500F, -3.2255F, 0.2500F, 0.2500F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -2.0000F, 2.5000F, 1.0472F, 0.0000F, 0.0000F));
        aleta_2.method_32117("aleta_2_c17", class_5606.method_32108().method_32101(50, 11).method_32098(0.1600F, -1.9000F, -3.2255F, 0.0000F, 2.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -1.8000F, 2.4000F, 1.2217F, 0.0000F, 0.0000F));
        aleta_2.method_32117("aleta_2_c18", class_5606.method_32108().method_32101(25, 37).method_32098(0.1600F, -0.5000F, -3.2255F, 0.0000F, 1.6000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -3.0000F, 3.6000F, 0.8290F, 0.0000F, 0.0000F));
        class_5610 aleta_3 = head.method_32117("aleta_3", class_5606.method_32108(), class_5603.method_32091(1.3000F, 1.8000F, -2.0745F, 0.0000F, 0.0000F, 2.1380F));
        aleta_3.method_32117("aleta_3_c38", class_5606.method_32108().method_32101(10, 26).method_32098(-0.2500F, -0.4000F, -0.2255F, 0.5000F, 0.5000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.0000F, 0.0000F, 0.0000F, 1.2217F, 0.0000F, 0.0000F));
        aleta_3.method_32117("aleta_3_c39", class_5606.method_32108().method_32101(24, 46).method_32098(-0.2250F, -0.1500F, -0.2255F, 0.2500F, 0.2500F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(0.1000F, 0.0000F, 2.5000F, 0.8727F, 0.0000F, 0.0000F));
        aleta_3.method_32117("aleta_3_c40", class_5606.method_32108().method_32101(20, 26).method_32098(-0.2250F, -0.1500F, -3.2255F, 0.2500F, 0.2500F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.1000F, -2.0000F, 2.5000F, 1.0472F, 0.0000F, 0.0000F));
        aleta_3.method_32117("aleta_3_c41", class_5606.method_32108().method_32101(9, 19).method_32098(-0.1600F, -1.9000F, -3.2255F, 0.0000F, 2.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.1000F, -1.8000F, 2.4000F, 1.2217F, 0.0000F, 0.0000F));
        aleta_3.method_32117("aleta_3_c42", class_5606.method_32108().method_32101(55, 37).method_32098(-0.1600F, -0.5000F, -3.2255F, 0.0000F, 1.6000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(0.1000F, -3.0000F, 3.6000F, 0.8290F, 0.0000F, 0.0000F));
        class_5610 jaw = head.method_32117("jaw", class_5606.method_32108(), class_5603.method_32090(-0.5000F, 1.3000F, -3.1745F));
        jaw.method_32117("jaw_c8", class_5606.method_32108().method_32101(45, 56).method_32098(-1.0000F, -0.1000F, -1.8255F, 1.0000F, 0.5000F, 1.5000F, new class_5605(0.0F)), class_5603.method_32091(1.0000F, 0.0000F, 0.0000F, 0.0873F, 0.0000F, 0.0000F));
        class_5610 body = dracopez.method_32117("body", class_5606.method_32108(), class_5603.method_32090(0.5000F, 3.3000F, 4.5745F));
        class_5610 parte_1 = body.method_32117("parte_1", class_5606.method_32108(), class_5603.method_32090(0.0000F, -3.3000F, -5.0000F));
        parte_1.method_32117("parte_1_c1", class_5606.method_32108().method_32101(0, 11).method_32098(-1.0000F, -1.6924F, -0.1545F, 2.0000F, 3.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.0000F, -0.1583F, 0.0538F, 0.3491F, 0.0000F, 0.0000F));
        parte_1.method_32117("parte_1_c19", class_5606.method_32108().method_32101(56, 42).method_32098(-0.0250F, -0.1500F, -3.2255F, 0.2500F, 0.2500F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -4.8000F, 2.2255F, 1.2217F, 0.0000F, 0.0000F));
        parte_1.method_32117("parte_1_c20", class_5606.method_32108().method_32101(30, 37).method_32098(0.2000F, -0.2000F, -3.2255F, 0.0000F, 1.3000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.2000F, -4.5000F, 2.3255F, 1.2217F, 0.0000F, 0.0000F));
        class_5610 ala_6 = parte_1.method_32117("ala_6", class_5606.method_32108(), class_5603.method_32090(-1.0000F, -2.1583F, 5.0538F));
        ala_6.method_32117("ala_6_c49", class_5606.method_32108().method_32101(49, 53).method_32098(-2.9000F, -0.1152F, -0.3507F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(-0.7000F, 0.0000F, -2.8000F, 0.3491F, 0.0000F, 0.2182F));
        ala_6.method_32117("ala_6_c50", class_5606.method_32108().method_32101(56, 56).method_32098(-0.9000F, -0.1152F, -0.3507F, 1.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(0.2000F, 0.0000F, -2.8000F, 0.3491F, 0.0000F, 0.0000F));
        ala_6.method_32117("ala_6_c51", class_5606.method_32108().method_32101(35, 50).method_32098(-2.9000F, 0.3848F, -0.3507F, 3.0000F, 0.0000F, 1.7500F, new class_5605(0.0F)), class_5603.method_32091(-0.4000F, -0.5000F, -2.3000F, 0.3491F, 0.0000F, 0.2182F));
        ala_6.method_32117("ala_6_c52", class_5606.method_32108().method_32101(0, 56).method_32098(-2.9000F, -0.1152F, -0.3507F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(-3.4225F, -0.5748F, -2.8054F, 0.2182F, 0.5672F, 0.0436F));
        ala_6.method_32117("ala_6_c53", class_5606.method_32108().method_32101(42, 46).method_32098(-3.9000F, 0.2348F, -0.3507F, 4.0000F, 0.1500F, 1.2500F, new class_5605(0.0F)), class_5603.method_32091(-3.4225F, -0.7748F, -2.4054F, 0.2182F, 0.5672F, 0.0436F));
        ala_6.method_32117("ala_6_c54", class_5606.method_32108().method_32101(0, 32).method_32098(-5.9000F, 0.3848F, -0.3507F, 6.0000F, 0.0000F, 3.2500F, new class_5605(0.0F)), class_5603.method_32091(-3.4225F, -0.8748F, -2.4054F, 0.2182F, 0.5672F, 0.0436F));
        class_5610 ala_5 = parte_1.method_32117("ala_5", class_5606.method_32108(), class_5603.method_32090(1.0000F, -2.1583F, 5.0538F));
        ala_5.method_32117("ala_5_c43", class_5606.method_32108().method_32101(51, 56).method_32098(-0.1000F, -0.1152F, -0.3507F, 1.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(-0.2000F, 0.0000F, -2.8000F, 0.3491F, 0.0000F, 0.0000F));
        ala_5.method_32117("ala_5_c44", class_5606.method_32108().method_32101(31, 53).method_32098(-0.1000F, -0.1152F, -0.3507F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(0.7000F, 0.0000F, -2.8000F, 0.3491F, 0.0000F, -0.2182F));
        ala_5.method_32117("ala_5_c45", class_5606.method_32108().method_32101(24, 50).method_32098(-0.1000F, 0.3848F, -0.3507F, 3.0000F, 0.0000F, 1.7500F, new class_5605(0.0F)), class_5603.method_32091(0.4000F, -0.5000F, -2.3000F, 0.3491F, 0.0000F, -0.2182F));
        ala_5.method_32117("ala_5_c46", class_5606.method_32108().method_32101(40, 53).method_32098(-0.1000F, -0.1152F, -0.3507F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(3.4225F, -0.5748F, -2.8054F, 0.2182F, -0.5672F, -0.0436F));
        ala_5.method_32117("ala_5_c47", class_5606.method_32108().method_32101(30, 46).method_32098(-0.1000F, 0.2348F, -0.3507F, 4.0000F, 0.1500F, 1.2500F, new class_5605(0.0F)), class_5603.method_32091(3.4225F, -0.7748F, -2.4054F, 0.2182F, -0.5672F, -0.0436F));
        ala_5.method_32117("ala_5_c48", class_5606.method_32108().method_32101(30, 26).method_32098(-0.1000F, 0.3848F, -0.3507F, 6.0000F, 0.0000F, 3.2500F, new class_5605(0.0F)), class_5603.method_32091(3.4225F, -0.8748F, -2.4054F, 0.2182F, -0.5672F, -0.0436F));
        class_5610 parte_2 = parte_1.method_32117("parte_2", class_5606.method_32108().method_32101(13, 11).method_32098(-1.0000F, -1.1583F, -0.3000F, 2.0000F, 2.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32090(0.0000F, -1.3000F, 3.3000F));
        class_5610 ala_13 = parte_2.method_32117("ala_13", class_5606.method_32108(), class_5603.method_32090(-1.0000F, 0.0583F, 4.7538F));
        ala_13.method_32117("ala_13_c55", class_5606.method_32108().method_32101(9, 56).method_32098(-2.9000F, -0.3848F, 0.2462F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(-0.7000F, 0.0000F, -2.8000F, -0.3491F, 0.0000F, -0.2182F));
        ala_13.method_32117("ala_13_c56", class_5606.method_32108().method_32101(0, 59).method_32098(-0.9000F, -0.3848F, 0.2462F, 1.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(0.2000F, 0.0000F, -2.8000F, -0.3491F, 0.0000F, 0.0000F));
        ala_13.method_32117("ala_13_c57", class_5606.method_32108().method_32101(46, 50).method_32098(-2.9000F, -0.3848F, -0.2538F, 3.0000F, 0.0000F, 1.7500F, new class_5605(0.0F)), class_5603.method_32091(-0.4000F, 0.5000F, -2.3000F, -0.3491F, 0.0000F, -0.2182F));
        ala_13.method_32117("ala_13_c58", class_5606.method_32108().method_32101(18, 56).method_32098(-2.9000F, -0.3848F, 0.2516F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(-3.4225F, 0.5748F, -2.8054F, -0.2182F, 0.5672F, -0.0436F));
        ala_13.method_32117("ala_13_c59", class_5606.method_32108().method_32101(0, 50).method_32098(-3.9000F, -0.3848F, -0.1484F, 4.0000F, 0.1500F, 1.2500F, new class_5605(0.0F)), class_5603.method_32091(-3.4225F, 0.7748F, -2.4054F, -0.2182F, 0.5672F, -0.0436F));
        ala_13.method_32117("ala_13_c60", class_5606.method_32108().method_32101(20, 32).method_32098(-5.9000F, -0.3848F, -0.1484F, 6.0000F, 0.0000F, 3.2500F, new class_5605(0.0F)), class_5603.method_32091(-3.4225F, 0.8748F, -2.4054F, -0.2182F, 0.5672F, -0.0436F));
        class_5610 ala_14 = parte_2.method_32117("ala_14", class_5606.method_32108(), class_5603.method_32090(1.0000F, 0.0583F, 4.7538F));
        ala_14.method_32117("ala_14_c61", class_5606.method_32108().method_32101(5, 59).method_32098(-0.1000F, -0.3848F, 0.2462F, 1.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(-0.2000F, 0.0000F, -2.8000F, -0.3491F, 0.0000F, 0.0000F));
        ala_14.method_32117("ala_14_c62", class_5606.method_32108().method_32101(27, 56).method_32098(-0.1000F, -0.3848F, 0.2462F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(0.7000F, 0.0000F, -2.8000F, -0.3491F, 0.0000F, 0.2182F));
        ala_14.method_32117("ala_14_c63", class_5606.method_32108().method_32101(0, 53).method_32098(-0.1000F, -0.3848F, -0.2538F, 3.0000F, 0.0000F, 1.7500F, new class_5605(0.0F)), class_5603.method_32091(0.4000F, 0.5000F, -2.3000F, -0.3491F, 0.0000F, 0.2182F));
        ala_14.method_32117("ala_14_c64", class_5606.method_32108().method_32101(36, 56).method_32098(-0.1000F, -0.3848F, 0.2516F, 3.0000F, 0.5000F, 0.7500F, new class_5605(0.0F)), class_5603.method_32091(3.4225F, 0.5748F, -2.8054F, -0.2182F, -0.5672F, 0.0436F));
        ala_14.method_32117("ala_14_c65", class_5606.method_32108().method_32101(12, 50).method_32098(-0.1000F, -0.3848F, -0.1484F, 4.0000F, 0.1500F, 1.2500F, new class_5605(0.0F)), class_5603.method_32091(3.4225F, 0.7748F, -2.4054F, -0.2182F, -0.5672F, 0.0436F));
        ala_14.method_32117("ala_14_c66", class_5606.method_32108().method_32101(40, 32).method_32098(-0.1000F, -0.3848F, -0.1484F, 6.0000F, 0.0000F, 3.2500F, new class_5605(0.0F)), class_5603.method_32091(3.4225F, 0.8748F, -2.4054F, -0.2182F, -0.5672F, 0.0436F));
        parte_2.method_32117("parte_2_c21", class_5606.method_32108().method_32101(0, 46).method_32098(-0.0250F, -0.1500F, -3.2255F, 0.2500F, 0.2500F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -3.0000F, 2.8255F, 0.9163F, 0.0000F, 0.0000F));
        parte_2.method_32117("parte_2_c33", class_5606.method_32108().method_32101(40, 37).method_32098(-0.1600F, 1.0175F, -4.8122F, 0.0000F, 1.3000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(0.2000F, -4.7000F, 2.9255F, 0.9163F, 0.0000F, 0.0000F));
        class_5610 parte_3 = parte_2.method_32117("parte_3", class_5606.method_32108(), class_5603.method_32090(0.0000F, -0.5000F, 3.6000F));
        parte_3.method_32117("parte_3_c22", class_5606.method_32108().method_32101(6, 46).method_32098(-0.0250F, -0.1500F, -3.2255F, 0.2500F, 0.2500F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.1000F, -1.4023F, 2.9732F, 0.6109F, 0.0000F, 0.0000F));
        parte_3.method_32117("parte_3_c3", class_5606.method_32108().method_32101(26, 11).method_32098(-1.0000F, -1.1735F, -0.1740F, 2.0000F, 2.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.0000F, 0.6394F, -0.0984F, -0.2618F, 0.0000F, 0.0000F));
        parte_3.method_32117("parte_3_c34", class_5606.method_32108().method_32101(45, 37).method_32098(-0.1600F, -0.2000F, -3.2255F, 0.0000F, 1.3000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(0.2000F, -1.1023F, 3.0732F, 0.6109F, 0.0000F, 0.0000F));
        class_5610 parte_4 = parte_3.method_32117("parte_4", class_5606.method_32108(), class_5603.method_32090(-0.5000F, -0.3606F, 1.7016F));
        parte_4.method_32117("parte_4_c4", class_5606.method_32108().method_32101(39, 11).method_32098(-0.5000F, -1.0572F, -0.4073F, 1.0000F, 2.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.5000F, 1.7000F, 1.6000F, -0.0873F, 0.0000F, 0.0000F));
        parte_4.method_32117("parte_4_c35", class_5606.method_32108().method_32101(50, 37).method_32098(-0.1600F, -0.2000F, -3.2255F, 0.0000F, 1.3000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(0.7000F, -0.3417F, 4.7717F, 0.6109F, 0.0000F, 0.0000F));
        class_5610 aleta_4 = parte_4.method_32117("aleta_4", class_5606.method_32108(), class_5603.method_32090(0.5000F, 2.0000F, 2.5000F));
        aleta_4.method_32117("aleta_4_c23", class_5606.method_32108().method_32101(9, 37).method_32098(-0.1500F, -0.1303F, -0.1782F, 0.2500F, 0.2500F, 3.0000F, new class_5605(0.0F)), class_5603.method_32091(0.4000F, 0.0000F, -0.1000F, -0.0873F, 1.2217F, 0.0000F));
        aleta_4.method_32117("aleta_4_c24", class_5606.method_32108().method_32101(12, 46).method_32098(-0.0004F, -0.0175F, -0.0395F, 0.1250F, 0.1250F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(3.0000F, 0.2000F, 0.9000F, -0.0873F, 0.6109F, 0.0000F));
        aleta_4.method_32117("aleta_4_c25", class_5606.method_32108().method_32101(11, 53).method_32098(-2.0004F, 0.1075F, -0.0395F, 2.1250F, 0.0000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(2.9000F, 0.1000F, 0.9000F, -0.0873F, 0.6109F, 0.0000F));
        aleta_4.method_32117("aleta_4_c26", class_5606.method_32108().method_32101(0, 42).method_32098(-2.0004F, 0.1075F, -0.0395F, 2.1250F, 0.0000F, 3.0000F, new class_5605(0.0F)), class_5603.method_32091(0.3000F, -0.1000F, 0.1000F, -0.0873F, 1.2217F, 0.0000F));
        class_5610 aleta_5 = parte_4.method_32117("aleta_5", class_5606.method_32108(), class_5603.method_32090(0.5000F, 2.0000F, 2.5000F));
        aleta_5.method_32117("aleta_5_c27", class_5606.method_32108().method_32101(17, 37).method_32098(-0.1000F, -0.1303F, -0.1782F, 0.2500F, 0.2500F, 3.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.4000F, 0.0000F, -0.1000F, -0.0873F, -1.2217F, 0.0000F));
        aleta_5.method_32117("aleta_5_c28", class_5606.method_32108().method_32101(18, 46).method_32098(-0.1246F, -0.0175F, -0.0395F, 0.1250F, 0.1250F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-3.0000F, 0.2000F, 0.9000F, -0.0873F, -0.6109F, 0.0000F));
        aleta_5.method_32117("aleta_5_c29", class_5606.method_32108().method_32101(21, 53).method_32098(-0.1246F, 0.1075F, -0.0395F, 2.1250F, 0.0000F, 2.0000F, new class_5605(0.0F)), class_5603.method_32091(-2.9000F, 0.1000F, 0.9000F, -0.0873F, -0.6109F, 0.0000F));
        aleta_5.method_32117("aleta_5_c30", class_5606.method_32108().method_32101(12, 42).method_32098(-0.1246F, 0.1075F, -0.0395F, 2.1250F, 0.0000F, 3.0000F, new class_5605(0.0F)), class_5603.method_32091(-0.3000F, -0.1000F, 0.1000F, -0.0873F, -1.2217F, 0.0000F));
        class_5610 parte_5 = parte_4.method_32117("parte_5", class_5606.method_32108(), class_5603.method_32090(0.0000F, 2.0000F, 2.0000F));
        parte_5.method_32117("parte_5_c5", class_5606.method_32108().method_32101(18, 19).method_32098(-0.5000F, -0.5417F, -0.1538F, 1.0000F, 1.0000F, 4.0000F, new class_5605(0.0F)), class_5603.method_32091(0.5000F, 0.0000F, 3.0000F, 0.0873F, 0.0000F, 0.0000F));
        parte_5.method_32117("parte_5_c36", class_5606.method_32108().method_32101(10, 59).method_32098(-0.1600F, 0.1000F, -3.2255F, 0.0000F, 1.0000F, 1.0000F, new class_5605(0.0F)), class_5603.method_32091(0.7000F, -3.0417F, 6.5717F, 0.8290F, 0.0000F, 0.0000F));
        class_5610 parte_6 = parte_4.method_32117("parte_6", class_5606.method_32108(), class_5603.method_32090(0.5000F, 1.9606F, 8.3462F));
        parte_6.method_32117("parte_6_c6", class_5606.method_32108().method_32101(0, 37).method_32098(-0.3500F, -0.3421F, 0.0468F, 0.7000F, 0.7000F, 3.0000F, new class_5605(0.0F)), class_5603.method_32091(0.0000F, -0.2520F, 0.3451F, 0.3927F, 0.0000F, 0.0000F));
        class_5610 parte_9 = parte_6.method_32117("parte_9", class_5606.method_32108(), class_5603.method_32090(0.0000F, -0.3000F, 0.4523F));
        parte_9.method_32117("parte_9_c37", class_5606.method_32108().method_32101(0, 0).method_32098(-13.7500F, 0.3579F, 0.0468F, 13.3000F, 0.0000F, 10.0000F, new class_5605(0.0F)), class_5603.method_32091(7.1000F, -0.3520F, -0.0072F, 0.3927F, 0.0000F, 0.0000F));

        return class_5607.method_32110(modelData, 64, 64);
    }

    @Override
    public void setAngles(DracoPezRenderState state) {
        super.method_2819(state);

        if (state.field_53458) {
            // Follow the swimming direction (up / down)
            this.dracopez.field_3654 += state.field_53448 * (float) (Math.PI / 180.0);
            float headYaw = class_3532.method_15363(state.field_53447, -25.0F, 25.0F);
            this.head.field_3675 += headYaw * (float) (Math.PI / 180.0);
        }

        if (state.activeAnimation == null) {
            return;
        }

        switch (state.activeAnimation) {
            case SWIM -> this.swimAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case SWIM_FAST -> this.swimAnimation.method_71986(state.activeAnimationState, state.field_53328, 2f);
            case IDLE_WATER -> this.idleWaterAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case FLOP -> this.flopAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
        }
    }
}
