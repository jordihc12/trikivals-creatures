package com.jordi.trikivalscreatures.entity.dracopez.render;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import net.minecraft.class_11659;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;

/**
 * Renders the fins layer (white/grey texture) tinted with the DracoPez fin color.
 * The base texture leaves the fin pixels transparent, so both layers never overlap.
 */
public class DracoPezFinsFeatureRenderer extends class_3887<DracoPezRenderState, DracoPezModel> {
    private static final class_2960 FINS_TEXTURE = class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/dracopez/dracopez_fins.png");

    public DracoPezFinsFeatureRenderer(class_3883<DracoPezRenderState, DracoPezModel> context) {
        super(context);
    }

    @Override
    public void render(class_4587 matrices, class_11659 queue, int light, DracoPezRenderState state,
                       float limbAngle, float limbDistance) {
        if (state.field_53333) {
            return;
        }

        method_23199(this.method_17165(), FINS_TEXTURE, matrices, queue, light, state, state.finColor, 1);
    }
}
