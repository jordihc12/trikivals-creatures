package com.jordi.trikivalscreatures.entity.dracopez.render;

import com.jordi.trikivalscreatures.entity.dracopez.anims.DracoPezAnimation;
import net.minecraft.class_10042;
import net.minecraft.class_7094;

public class DracoPezRenderState extends class_10042 {
    public class_7094 activeAnimationState = new class_7094();
    public DracoPezAnimation activeAnimation;

    // ARGB color used to tint the fins layer
    public int finColor = 0xFFFFFFFF;
}
