package com.jordi.trikivalscreatures.entity.dracopez.render;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_4606;

/**
 * Emissive layer (glows in the dark like spider eyes): eyes, spine tips and lateral line dots.
 */
public class DracoPezGlowFeatureRenderer extends class_4606<DracoPezRenderState, DracoPezModel> {
    private static final class_1921 GLOW = class_12249.method_76014(
            class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/dracopez/dracopez_glow.png"));

    public DracoPezGlowFeatureRenderer(class_3883<DracoPezRenderState, DracoPezModel> context) {
        super(context);
    }

    @Override
    public class_1921 method_23193() {
        return GLOW;
    }
}
