package com.jordi.trikivalscreatures.entity.ai;

import net.minecraft.class_1309;

public interface CustomMeleeAttackMob {
    int getMeleeAttackRange();

    boolean canPerformMeleeAttack(class_1309 target);
}
