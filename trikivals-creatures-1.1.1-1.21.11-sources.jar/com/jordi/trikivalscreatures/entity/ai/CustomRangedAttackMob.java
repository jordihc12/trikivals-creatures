package com.jordi.trikivalscreatures.entity.ai;

import net.minecraft.class_1603;

public interface CustomRangedAttackMob extends class_1603 {
    int getRangeAggroMaxAttackRange();
    int getRangeAggroMinAttackRange();

    boolean canPerformRangedAttack();
}
