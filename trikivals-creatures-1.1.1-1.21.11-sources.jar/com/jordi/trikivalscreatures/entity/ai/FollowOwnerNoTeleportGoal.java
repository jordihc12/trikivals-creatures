package com.jordi.trikivalscreatures.entity.ai;

import java.util.EnumSet;
import net.minecraft.class_1309;
import net.minecraft.class_1321;
import net.minecraft.class_1352;
import net.minecraft.class_1407;
import net.minecraft.class_1408;
import net.minecraft.class_1409;
import net.minecraft.class_5766;
import net.minecraft.class_7;
import net.minecraft.entity.ai.pathing.*;

public class FollowOwnerNoTeleportGoal extends class_1352 {
    private final class_1321 tameable;
    private class_1309 owner;
    private final double speed;
    private final class_1408 navigation;
    private int updateCountdownTicks;
    private final float maxDistance;
    private final float minDistance;
    private float oldWaterPathfindingPenalty;

    public FollowOwnerNoTeleportGoal(class_1321 tameable, double speed, float minDistance, float maxDistance) {
        this.tameable = tameable;
        this.speed = speed;
        this.navigation = tameable.method_5942();
        this.minDistance = minDistance;
        this.maxDistance = maxDistance;
        this.method_6265(EnumSet.of(class_1352.class_4134.field_18405, class_1352.class_4134.field_18406));
        if (!this.isNavigationSupported(tameable.method_5942())) {
            throw new IllegalArgumentException("Unsupported mob type for FollowOwnerGoal");
        }
    }

    private boolean isNavigationSupported(class_1408 navigation) {
        return navigation instanceof class_1409 ||
                navigation instanceof class_1407 ||
                navigation instanceof class_5766;
    }

    @Override
    public boolean method_6264() {
        class_1309 livingEntity = this.tameable.method_35057();
        if (livingEntity == null) {
            return false;
        } else if (livingEntity.method_7325()) {
            return false;
        } else if (this.cannotFollow()) {
            return false;
        } else if (this.tameable.method_5858(livingEntity) < this.minDistance * this.minDistance) {
            return false;
        } else {
            this.owner = livingEntity;
            return true;
        }
    }

    @Override
    public boolean method_6266() {
        if (this.navigation.method_6357()) {
            return false;
        } else {
            return !this.cannotFollow() && !(this.tameable.method_5858(this.owner) <= this.maxDistance * this.maxDistance);
        }
    }

    private boolean cannotFollow() {
        return this.tameable.method_24345() || this.tameable.method_5765() || this.tameable.method_60953();
    }

    @Override
    public void method_6269() {
        this.updateCountdownTicks = 0;
        this.oldWaterPathfindingPenalty = this.tameable.method_5944(class_7.field_18);
        this.tameable.method_5941(class_7.field_18, 0.0F);
    }

    @Override
    public void method_6270() {
        this.owner = null;
        this.navigation.method_6340();
        this.tameable.method_5941(class_7.field_18, this.oldWaterPathfindingPenalty);
    }

    @Override
    public void method_6268() {
        this.tameable.method_5988().method_6226(this.owner, 10.0F, this.tameable.method_5978());
        if (--this.updateCountdownTicks <= 0) {
            this.updateCountdownTicks = this.method_38847(10);
            if (this.tameable.method_5858(this.owner) < 144.0) {
                this.navigation.method_6335(this.owner, this.speed);
            }
        }
    }
}
