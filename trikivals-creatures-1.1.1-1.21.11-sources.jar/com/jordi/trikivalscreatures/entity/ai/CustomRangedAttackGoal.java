package com.jordi.trikivalscreatures.entity.ai;

import net.minecraft.class_1308;
import net.minecraft.class_1381;

public class CustomRangedAttackGoal extends class_1381 {
    private final CustomRangedAttackMob entity;
    private final int AGGRO_RANGE_MAX;
    private final int AGGRO_RANGE_MIN;

    public CustomRangedAttackGoal(CustomRangedAttackMob mob, double mobSpeed, int maxRange, int minRange, int intervalTicks, float maxShootRange) {
        super(mob, mobSpeed, intervalTicks, maxShootRange);
        AGGRO_RANGE_MAX = maxRange;
        AGGRO_RANGE_MIN = minRange;
        entity = mob;
    }

    private boolean isWithinDistance() {
        if(entity instanceof class_1308 mobEntity && mobEntity.method_5968() != null) {
            double distance = mobEntity.method_5739(mobEntity.method_5968());
            return distance >= AGGRO_RANGE_MIN && distance <= AGGRO_RANGE_MAX;
        }
        return false;
    }

    @Override
    public boolean method_6264() {
        if(this.entity == null) return false;

        return this.entity.canPerformRangedAttack() && isWithinDistance() && super.method_6264();
    }

    @Override
    public boolean method_6266() {
        return this.isWithinDistance();
    }
}
