package com.jordi.trikivalscreatures.entity.ai;

import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1400;

public class TerritorialTargetGoal<T extends class_1309> extends class_1400<T> {
    private final float INTERVAL_TO_AGGRESSIVE;
    private float entityNearFor = 0;
    private class_1309 lastTargetEntity = null;

    private final CustomMeleeAttackMob entity;

    private final float TARGET_RANGE;

    //TODO: Create mob types blacklist and override findClosestTarget so it ignores the blacklisted types

    public TerritorialTargetGoal(CustomMeleeAttackMob mob, Class<T> targetClass, float targetRange, float intervalToAggressive) {
        super((class_1308) mob, targetClass, true);
        this.entity = mob;
        this.TARGET_RANGE = targetRange;
        this.INTERVAL_TO_AGGRESSIVE = intervalToAggressive;
    }

    @Override
    public boolean method_38846() {
        return true;
    }

    @Override
    public boolean method_6264() {
        this.method_18415();
        if(!this.entity.canPerformMeleeAttack(this.field_6644)) return false;
        if(this.field_6660.method_5858(this.field_6644) >= TARGET_RANGE * TARGET_RANGE) return false;

        this.entityNearFor++;
        if(this.lastTargetEntity != this.field_6644) {
            this.entityNearFor = 0;
            this.lastTargetEntity = this.field_6644;
        }

        if(this.entityNearFor >= INTERVAL_TO_AGGRESSIVE) return super.method_6264();

        return false;
    }
}
