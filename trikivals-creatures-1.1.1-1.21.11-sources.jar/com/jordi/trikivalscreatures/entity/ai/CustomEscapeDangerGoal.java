package com.jordi.trikivalscreatures.entity.ai;

import java.util.function.Function;
import net.minecraft.class_1314;
import net.minecraft.class_1374;
import net.minecraft.class_243;
import net.minecraft.class_5532;
import net.minecraft.class_6862;
import net.minecraft.class_8103;
import net.minecraft.class_8110;

/**
 * Custom EscapeDangerGoal that expects horizontal and vertical range to find the position it needs to flee.
 * If no horizontal and vertical are passed it takes the default value of 5, making this class equal to EscapeDangerGoal.
 * **/
public class CustomEscapeDangerGoal extends class_1374 {
    private final int horizontalRange;
    private final int verticalRange;

    public CustomEscapeDangerGoal(class_1314 mob, double speed) {
        this(mob, speed, 5, 5, class_8103.field_51990);
    }

    public CustomEscapeDangerGoal(class_1314 mob, double speed, int horizontalRange, int verticalRange) {
        this(mob, speed, horizontalRange, verticalRange, class_8103.field_51990);
    }

    public CustomEscapeDangerGoal(class_1314 mob, double speed, int horizontalRange, int verticalRange, class_6862<class_8110> dangerousDamageTypes) {
        this(mob, speed, horizontalRange, verticalRange, entity -> dangerousDamageTypes);
    }

    public CustomEscapeDangerGoal(class_1314 mob, double speed, int horizontalRange, int verticalRange, Function<class_1314, class_6862<class_8110>> entityToDangerousDamageTypes) {
        super(mob, speed, entityToDangerousDamageTypes);

        this.horizontalRange = horizontalRange;
        this.verticalRange = verticalRange;
    }

    @Override
    protected boolean method_6301() {
        class_243 vec3d = class_5532.method_31510(this.field_6549, horizontalRange, verticalRange);
        if (vec3d == null) {
            return false;
        } else {
            this.field_6547 = vec3d.field_1352;
            this.field_6546 = vec3d.field_1351;
            this.field_6550 = vec3d.field_1350;
            return true;
        }
    }
}
