package com.jordi.trikivalscreatures.entity;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import com.jordi.trikivalscreatures.entity.palgaster.PalgasterEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.spit.PejelagartoSpitEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

//Helper class that initialize custom Mobs
public class ModEntities {
    private static final class_5321<class_1299<?>> PEJELAGARTO_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto"));
    private static final class_5321<class_1299<?>> PEJELAGARTO_SPIT_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto_spit"));

    private static final class_5321<class_1299<?>> DRACOPEZ_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "dracopez"));

    private static final class_5321<class_1299<?>> PALGASTER_KEY =
            class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "palgaster"));

    public static final class_1299<PejelagartoEntity> PEJELAGARTO = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto"),
            class_1299.class_1300.method_5903(PejelagartoEntity::new, class_1311.field_6294)
                    .method_17687(0.45f, 0.2f).method_5905(PEJELAGARTO_KEY));

    public static final class_1299<PejelagartoSpitEntity> PEJELAGARTO_SPIT = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto_spit"),
            class_1299.class_1300.method_5903((class_1299.class_4049<PejelagartoSpitEntity>)PejelagartoSpitEntity::new, class_1311.field_17715)
                    .method_17687(0.25F, 0.25F).method_5905(PEJELAGARTO_SPIT_KEY));

    // Hitbox at scale 1. The real size depends on each DracoPez (SCALE attribute): 1.5 to 2 blocks long (babies 0.75)
    public static final class_1299<DracoPezEntity> DRACOPEZ = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TrikiValsCreatures.MOD_ID, "dracopez"),
            class_1299.class_1300.method_5903(DracoPezEntity::new, class_1311.field_24460)
                    .method_17687(1.0f, 0.5f).method_5905(DRACOPEZ_KEY));

    // Palgaster: rideable mount, a bit taller than the player
    public static final class_1299<PalgasterEntity> PALGASTER = class_2378.method_10230(class_7923.field_41177,
            class_2960.method_60655(TrikiValsCreatures.MOD_ID, "palgaster"),
            class_1299.class_1300.method_5903(PalgasterEntity::new, class_1311.field_6294)
                    .method_17687(1.3f, 1.9f)
                    .method_55689(1.62f)
                    .method_27299(10)
                    .method_5905(PALGASTER_KEY));

    public static void registerEntities() {
        TrikiValsCreatures.LOGGER.info("Registering entities!");

        FabricDefaultAttributeRegistry.register(ModEntities.PEJELAGARTO, PejelagartoEntity.createPejelagartoAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.DRACOPEZ, DracoPezEntity.createDracoPezAttributes());
        FabricDefaultAttributeRegistry.register(ModEntities.PALGASTER, PalgasterEntity.createPalgasterAttributes());
    }
}
