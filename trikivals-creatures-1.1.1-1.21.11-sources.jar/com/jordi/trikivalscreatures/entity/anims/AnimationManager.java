package com.jordi.trikivalscreatures.entity.anims;

import java.util.EnumMap;
import net.minecraft.class_1297;
import net.minecraft.class_7094;

public abstract class AnimationManager<U extends class_1297, T extends Enum<T> & IAnimation> {

    private static class AnimationData {
        int cooldown;
        class_7094 animationState;
        boolean animationFinished;

        AnimationData() {
            cooldown = 0;
            animationState = new class_7094();
            animationFinished = false;
        }
    }

    private T activeAnim;

    private final EnumMap<T, AnimationManager.AnimationData> animations;

    public AnimationManager(Class<T> animClass, T defaultAnims) {
        this.animations = new EnumMap<>(animClass);
        for (T anim : animClass.getEnumConstants()) {
            animations.put(anim, new AnimationData());
        }

        activeAnim = defaultAnims;
    }

    public final class_7094 getAnimationStateFor(T anim) {
        return animations.get(anim).animationState;
    }

    public void stopAnimation(T anim) {
        animations.get(anim).animationState.method_41325();
    }

    public void resetAnimationCooldownFor(T anim) {
        animations.get(anim).cooldown = 0;
    }

    public final T getActiveAnim() {
        return activeAnim;
    }

    public abstract T getActiveAnimationPriv(U entity);

    public void updateActiveAnimation(U entity) {
        T nextAnim = getActiveAnimationPriv(entity);

        setActiveAnim(nextAnim, entity.field_6012);
    }

    public void setActiveAnim(T nextAnim, int entityAge) {
        if(nextAnim != activeAnim) {
            resetAnim(activeAnim, entityAge);

            activeAnim = nextAnim;
        }
    }

    private void resetAnim(T anim, int age) {
        AnimationData data = animations.get(anim);
        data.animationFinished = false;
        data.animationState.method_41325();
        data.animationState.method_41322(age);
    }

    public void updateAnimations(int tick) {
        AnimationData animationData = animations.get(activeAnim);

        if(animationData.cooldown <= 0) {
            if(activeAnim.getLoop() || !animationData.animationFinished) {
                animationData.animationFinished = true;
                animationData.cooldown = activeAnim.getTickLength();
                animationData.animationState.method_41322(tick);
            }
        }
        else {
            --animationData.cooldown;
        }
    }
}
