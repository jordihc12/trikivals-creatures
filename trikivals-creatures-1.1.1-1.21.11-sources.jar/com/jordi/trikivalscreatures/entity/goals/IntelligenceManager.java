package com.jordi.trikivalscreatures.entity.goals;

import java.util.function.Function;
import net.minecraft.class_1308;
import net.minecraft.class_1352;

public abstract class IntelligenceManager<T extends class_1308> {
    private int goalPriority;
    private int targetPriority;
    protected final T entity;

    protected IntelligenceManager(T entity) {
        this.entity = entity;
        goalPriority = 0;
        targetPriority = 0;
    }

    protected void addGoal(class_1352 goal) {
        entity.field_6201.method_6277(goalPriority, goal);
        goalPriority++;
    }

    protected void addGoal(class_1352[] goals) {
        for (var goal: goals) {
            entity.field_6201.method_6277(goalPriority, goal);
        }
        goalPriority++;
    }

    protected void addTarget(class_1352 goal) {
        entity.field_6185.method_6277(targetPriority, goal);
        targetPriority++;
    }

    protected void addTarget(class_1352[] goals) {
        for (var goal: goals) {
            entity.field_6185.method_6277(targetPriority, goal);
        }
        targetPriority++;
    }

    public abstract void setGoalsPriv();

    /**
     * The "Universal" static initializer.
     * @param entity The entity instance
     * @param factory The IntelligenceManager subclass initializer
     */
    public static <T extends class_1308> void setGoals(T entity, Function<T, IntelligenceManager<T>> factory) {
        factory.apply(entity).setGoalsPriv();
    }
}
