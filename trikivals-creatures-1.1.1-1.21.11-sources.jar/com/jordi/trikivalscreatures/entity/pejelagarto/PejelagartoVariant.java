
package com.jordi.trikivalscreatures.entity.pejelagarto;

import com.mojang.serialization.Codec;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_3542;
import net.minecraft.class_5321;

@SuppressWarnings("unchecked")
public enum PejelagartoVariant implements class_3542 {
    PLAINS(
        "plains",
        0,
        1.0F
    ),
    JUNGLE(
        "jungle",
        1,
        1.0F,
        new class_5321[]{class_1972.field_9417}
    ),
    PINK(
        "pink",
        2,
        0.8F,
        new class_5321[] {class_1972.field_9462}
    ),
    SAND(
        "sand",
        3,
        1.0F,
        new class_5321[] {class_1972.field_9424}
    ),
    ALBINO(
        "albino",
        4,
        2.0F,
        null
    );

    public static final Codec<PejelagartoVariant> CODEC = class_3542.method_28140(PejelagartoVariant::values);

    private static final PejelagartoVariant[] BY_ID = Arrays.stream(values()).sorted(
            Comparator.comparingInt(PejelagartoVariant::getId)).toArray(PejelagartoVariant[]::new);
    private final int id;

    private final float size;

    // List of biomes where each variant spawn. Can have 3 values:
    // - biomes = new RegistryKey[]{ BiomeKeys.BIOME_1, BiomeKeys.BIOME_2, ... } -> variant can spawn in any biome present in the list
    // - biomes = new RegistryKey[]{} -> variant can spawn in any biome the entity spawns
    // - biomes = null -> variant cannot spawn in any biome
    private class_5321<class_1959>[] biomes = new class_5321[]{};
    private final String name;

    PejelagartoVariant(String name, int id, float size) {
        this.id = id;
        this.name = name;
        this.size = size;
    }

    PejelagartoVariant(String name, int id, float size, class_5321<class_1959>[] biomes) {
        this.name = name;
        this.id = id;
        this.size = size;
        this.biomes = biomes;
    }

    public class_5321<class_1959>[] getSpawnBiomes() {
        return this.biomes;
    }

    public int getId() {
        return this.id;
    }

    public static PejelagartoVariant byId(int id) {
        return BY_ID[id % BY_ID.length];
    }

    public static @Nullable PejelagartoVariant byName(String name) {
        for (var variant : BY_ID) {
            if(Objects.equals(variant.name, name)) return variant;
        }
        return null;
    }

    public float getVariantSize() {
        return size;
    }

    @Override
    public String method_15434() {
        return name;
    }
}
