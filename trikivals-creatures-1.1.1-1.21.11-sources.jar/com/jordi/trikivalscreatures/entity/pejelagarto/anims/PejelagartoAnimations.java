package com.jordi.trikivalscreatures.entity.pejelagarto.anims;

import net.minecraft.class_7179;
import net.minecraft.class_7184;
import net.minecraft.class_7186;
import net.minecraft.class_7187;
import net.minecraft.client.render.entity.animation.*;

public class PejelagartoAnimations {
        public static final class_7184 PEJELAGARTO_IDLE = class_7184.class_7185.method_41818(1.5F).method_41817()
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.9167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.125F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.3333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.375F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("torso", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.375F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.9167F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.125F, class_7187.method_41829(27.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.3333F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.9167F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.125F, class_7187.method_41823(0.0F, -0.4F, 0.35F), class_7179.class_7181.field_37884),
                        new class_7186(1.3333F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41821();

        public static final class_7184 PEJELAGARTO_WALK = class_7184.class_7185.method_41818(1.0F).method_41817()
                .method_41820("left_first", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_second", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_third", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(17.5F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_first", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_second", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_third", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-17.5F, 0.0F, 10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-12.5F, 12.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-12.5F, -12.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, -0.375F, 0.25F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(0.25F, -0.375F, -0.15F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, -0.375F, 0.25F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(-0.25F, -0.375F, -0.15F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, -0.375F, 0.25F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-12.5F, -12.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-12.5F, 12.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-12.5F, -12.5F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(-0.3091F, -0.3F, 0.1216F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(0.0F, -0.3F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.2929F, -0.3F, 0.0649F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.0F, -0.3F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(-0.3091F, -0.3F, 0.1216F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-12.5F, -12.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-12.5F, 12.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, -0.3F, 0.2F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(-0.3139F, -0.3F, 0.0994F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, -0.3F, 0.2F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.3111F, -0.3F, 0.1244F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, -0.3F, 0.2F), class_7179.class_7181.field_37884)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(2.2718F, 7.0825F, -1.3039F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(2.3028F, -7.3173F, -2.8867F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41821();

        public static final class_7184 PEJELAGARTO_SWIM = class_7184.class_7185.method_41818(1.0F).method_41817()
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, -0.6F, -0.7F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, -0.6F, -0.7F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, -2.5F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 2.5F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, -2.5F, -10.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.2F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.2F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_first", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_second", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(52.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(52.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(52.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_third", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(50.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(50.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(50.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(62.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(62.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(62.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, -2.5F, 15.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 2.5F, 15.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, -2.5F, 15.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(-0.3F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(-0.3F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_first", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(45.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(45.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_second", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(45.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(45.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(45.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_third", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(57.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(57.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(47.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(57.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(67.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(67.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(55.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("torso", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, -2.5024F, -0.1091F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 2.5F, -0.4352F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, -2.5024F, -0.1091F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-12.5F, -7.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-12.5F, 7.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-12.5F, -7.5F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.25F, class_7187.method_41823(0.0F, -0.3F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.0F, -0.3F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-15.1212F, 17.4828F, -0.7879F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-15.0034F, -10.0F, 0.3262F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-15.0881F, -14.9854F, 0.9987F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-15.1212F, 10.0F, -0.7879F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-15.1212F, 17.4828F, -0.7879F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, -0.35F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(0.0F, -0.35F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, -0.35F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.0F, -0.35F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, -0.35F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-6.9861F, 27.8984F, 3.6651F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(-6.867F, -20.3866F, -2.5978F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-7.1809F, -27.0F, -3.1547F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41829(-6.9861F, 20.8984F, 3.6651F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-6.9861F, 27.8984F, 3.6651F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.6F, -0.2F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(-0.6F, -0.2F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(-0.6F, -0.2F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.75F, class_7187.method_41823(0.6F, -0.2F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.6F, -0.2F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41821();

        public static final class_7184 PEJELAGARTO_IDLE_WATER = class_7184.class_7185.method_41818(2.0F).method_41817()
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, 0.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("mouth", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, -47.5F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, -47.5F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, -47.5F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(2.3F, -1.8F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(2.3F, -0.8F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(2.3F, -1.8F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41823(2.3F, -2.3F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41823(2.3F, -1.8F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_first", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, -12.5F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -5.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_second", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 7.5F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -37.5F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_third", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, -25.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -20.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(27.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(19.8423F, 2.5587F, -7.0524F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(27.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(26.4032F, 7.9813F, -15.6249F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(27.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 47.5F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 47.5F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 47.5F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(-2.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(-2.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(-2.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41823(-2.0F, -1.5F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41823(-2.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_first", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, -12.5F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, 22.5F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_second", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 20.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, -10.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_third", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 22.5F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(0.0F, 0.0F, 25.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(27.3593F, -2.2494F, 7.1566F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(34.3569F, -7.1314F, 10.2928F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("torso", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("torso", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, 0.6F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41823(0.0F, -0.4F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.0F, class_7187.method_41829(-7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(-2.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(-7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(1.5F, class_7187.method_41829(7.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(2.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41821();

        public static final class_7184 PEJELAGARTO_FALL = class_7184.class_7185.method_41818(0.5F).method_41817()
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-35.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.125F, class_7187.method_41829(-36.6915F, 16.2701F, -11.792F), class_7179.class_7181.field_37884),
                        new class_7186(0.375F, class_7187.method_41829(-36.6839F, -16.2753F, 11.7053F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(-35.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(27.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, -0.5F, 0.5F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-5.0F, 0.0F, -67.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(3.5F, -2.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(35.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("left_fourth", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.5F, -0.5F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-1.9176F, 4.6185F, 67.4227F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(-3.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_fourth", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(45.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("right_fourth", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.5F, -0.5F), class_7179.class_7181.field_37884)
                ))
                .method_41820("torso", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(-5.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(12.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41821();

        public static final class_7184 PEJELAGARTO_ATTACK = class_7184.class_7185.method_41818(0.5F)
                .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("head", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(0.0F, -1.0F, -0.7F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(32.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("jaw", new class_7179(class_7179.class_7183.field_37886,
                        new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41823(0.0F, -0.5F, 0.5F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("torso", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37887,
                        new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.25F, class_7187.method_41829(10.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                        new class_7186(0.5F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
                ))
                .method_41821();

    public static final class_7184 PEJELAGARTO_SIT = class_7184.class_7185.method_41818(1.25F)
            .method_41820("body", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("head", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.3333F, class_7187.method_41829(-22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41829(-40.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(0.0F, -20.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("head", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.3333F, class_7187.method_41823(0.0F, -1.0F, -0.5F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41823(0.0F, -1.5F, 0.2F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(0.0F, -2.0F, -1.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41823(0.0F, -2.0F, -1.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("jaw", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.3333F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41829(22.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("jaw", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.3333F, class_7187.method_41823(0.0F, -0.5F, 0.5F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41823(0.0F, -0.5F, 0.5F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, -42.5F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(0.0F, 0.0F, -42.5F), class_7179.class_7181.field_37884)
            ))
            .method_41820("left_legs", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(2.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41823(2.0F, -2.5F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(0.0F, 0.0F, 50.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(0.0F, 0.0F, 50.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("right_legs", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(-2.0F, -1.8F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41823(-2.0F, -1.8F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("torso", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.3333F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41823(0.0F, -1.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.3333F, class_7187.method_41829(-15.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41829(-15.0881F, 14.9854F, -0.6696F), class_7179.class_7181.field_37884)
            ))
            .method_41820("tail_1", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.3333F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41829(15.0F, 20.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(-12.5F, 20.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(-12.5F, 20.0F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("tail_2", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41823(0.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37887,
                    new class_7186(0.0F, class_7187.method_41829(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41829(12.5F, 17.5F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41829(-23.7921F, 32.2456F, -3.0461F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41829(-23.7921F, 32.2456F, -3.0461F), class_7179.class_7181.field_37884)
            ))
            .method_41820("tail_3", new class_7179(class_7179.class_7183.field_37886,
                    new class_7186(0.0F, class_7187.method_41823(0.0F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(0.625F, class_7187.method_41823(0.5F, 0.0F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.0F, class_7187.method_41823(1.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884),
                    new class_7186(1.25F, class_7187.method_41823(1.0F, -0.5F, 0.0F), class_7179.class_7181.field_37884)
            ))
            .method_41821();
    }
