package com.jordi.trikivalscreatures.entity.pejelagarto.anims;

import com.jordi.trikivalscreatures.entity.anims.AnimationManager;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;

public class PejelagartoAnimatorManager extends AnimationManager<PejelagartoEntity, PejelagartoAnimation> {

    public PejelagartoAnimatorManager() {
        super(PejelagartoAnimation.class, PejelagartoAnimation.IDLE);
    }

    @Override
    public PejelagartoAnimation getActiveAnimationPriv(PejelagartoEntity entity) {
        if(entity.getIsSitting()) {
            return PejelagartoAnimation.SIT;
        }
        else if(entity.method_6510()) {
            return PejelagartoAnimation.ATTACK;
        }
        else if(!entity.method_24828() && entity.method_60478().method_10214() < -0.5F) {
            return PejelagartoAnimation.FALL;
        }
        else if(entity.method_60478().method_37267() > 0.01) {
            return entity.method_5799() ? PejelagartoAnimation.SWIM : PejelagartoAnimation.WALK;
        }
        else {
            return entity.method_5799() ? PejelagartoAnimation.IDLE_WATER : PejelagartoAnimation.IDLE;
        }
    }
}
