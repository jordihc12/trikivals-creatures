package com.jordi.trikivalscreatures.entity.pejelagarto.render;

import com.google.common.collect.Maps;
import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimation;
import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimatorManager;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import java.util.Map;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_927;

public class PejelagartoRenderer extends class_927<PejelagartoEntity, PejelagartoRenderState, PejelagartoModel> {
    private static final Map<PejelagartoVariant, class_2960> TEXTURES = class_156.method_654(Maps.newEnumMap(PejelagartoVariant.class), map -> {
        map.put(PejelagartoVariant.PLAINS, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/pejelagarto_plains.png"));
        map.put(PejelagartoVariant.JUNGLE, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/pejelagarto_jungle.png"));
        map.put(PejelagartoVariant.PINK, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/pejelagarto_pink.png"));
        map.put(PejelagartoVariant.SAND, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/pejelagarto_sand.png"));
        map.put(PejelagartoVariant.ALBINO, class_2960.method_60655(TrikiValsCreatures.MOD_ID, "textures/entity/pejelagarto_albino.png"));
    });

    public PejelagartoRenderer(class_5617.class_5618 context) {
        super(context, new PejelagartoModel(context.method_32167(PejelagartoModel.PEJELAGARTO)), 0.4f);
    }

    @Override
    public class_2960 getTexture(PejelagartoRenderState state) {
        return TEXTURES.get(state.variant);
    }

    @Override
    public void render(PejelagartoRenderState state, class_4587 matrixStack,
                       class_11659 orderedRenderCommandQueue, class_12075 cameraRenderState) {
        float scalingFactor = state.variant.getVariantSize();

        if(state.field_53457) {
            scalingFactor *= 0.5f;
        }
        matrixStack.method_22905(scalingFactor, scalingFactor, scalingFactor);

        super.method_4054(state, matrixStack, orderedRenderCommandQueue, cameraRenderState);
    }

    @Override
    public PejelagartoRenderState method_55269() {
        return new PejelagartoRenderState();
    }

    @Override
    public void updateRenderState(PejelagartoEntity pejelagartoEntity, PejelagartoRenderState pejelagartoRenderState, float f) {
        super.method_62355(pejelagartoEntity, pejelagartoRenderState, f);

        pejelagartoRenderState.variant = pejelagartoEntity.getVariant();

        PejelagartoAnimatorManager manager = pejelagartoEntity.getAnimationManager();
        var activeAnimation = manager.getActiveAnim();

        //Animation States
        pejelagartoRenderState.idleAnimationState.method_61401(
                manager.getAnimationStateFor
                        (pejelagartoEntity.method_5799() ?
                                PejelagartoAnimation.IDLE : PejelagartoAnimation.IDLE_WATER
                        )
        );

        pejelagartoRenderState.activeAnimation = activeAnimation;
        pejelagartoRenderState.activeAnimationState.method_61401(manager.getAnimationStateFor(activeAnimation));

        pejelagartoRenderState.inWater = pejelagartoEntity.method_5799();
    }
}
