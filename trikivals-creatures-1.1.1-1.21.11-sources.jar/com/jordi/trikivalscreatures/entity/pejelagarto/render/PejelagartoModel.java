package com.jordi.trikivalscreatures.entity.pejelagarto.render;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimations;
import net.minecraft.class_11509;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5601;
import net.minecraft.class_5603;
import net.minecraft.class_5605;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_583;
import net.minecraft.class_630;
import net.minecraft.client.model.*;

public class PejelagartoModel extends class_583<PejelagartoRenderState> {
    public static final class_5601 PEJELAGARTO = new class_5601(class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto"), "main");

	private final class_630 field_54014;
    private final class_630 head;

    //--- ANIMATIONS ---
    //IDLE
    private final class_11509 idlingAnimation;
    private final class_11509 idlingWaterAnimation;

    //ATTACK
    private final class_11509 attackAnimation;

    //NOT TOUCHING GROUND
    private final class_11509 fallAnimation;

    //SIT
    private final class_11509 sitAnimation;

    //MOVEMENT
    private final class_11509 walkingAnimation;
    private final class_11509 swimAnimation;

	public PejelagartoModel(class_630 root) {
        super(root);
        this.field_54014 = root.method_32086("pejelagarto");
        this.head = this.field_54014.method_32086("body").method_32086("head");

        this.walkingAnimation = PejelagartoAnimations.PEJELAGARTO_WALK.method_71979(root);
        this.idlingAnimation = PejelagartoAnimations.PEJELAGARTO_IDLE.method_71979(root);
        this.idlingWaterAnimation = PejelagartoAnimations.PEJELAGARTO_IDLE_WATER.method_71979(root);
        this.swimAnimation = PejelagartoAnimations.PEJELAGARTO_SWIM.method_71979(root);
        this.attackAnimation = PejelagartoAnimations.PEJELAGARTO_ATTACK.method_71979(root);
        this.fallAnimation = PejelagartoAnimations.PEJELAGARTO_FALL.method_71979(root);
        this.sitAnimation = PejelagartoAnimations.PEJELAGARTO_SIT.method_71979(root);
	}

    //TODO: Volver a exportar el modelo para la nueva version
    public static class_5607 getTexturedModelData() {
        class_5609 modelData = new class_5609();
        class_5610 modelPartData = modelData.method_32111();
        class_5610 pejelagarto = modelPartData.method_32117("pejelagarto", class_5606.method_32108(), class_5603.method_32090(0.0F, 24.0F, 0.0F));

        class_5610 body = pejelagarto.method_32117("body", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

        class_5610 head = body.method_32117("head", class_5606.method_32108().method_32101(11, 0).method_32098(-1.5F, -1.0F, -0.6667F, 1.0F, 1.0F, 2.0F, new class_5605(0.0F))
                .method_32101(11, 0).method_32096().method_32098(0.5F, -1.0F, -0.6667F, 1.0F, 1.0F, 2.0F, new class_5605(0.0F)).method_32106(false), class_5603.method_32090(0.5F, -4.0F, -5.3133F));

        class_5610 mouth = head.method_32117("mouth", class_5606.method_32108().method_32101(0, 6).method_32098(-1.5F, -0.75F, 0.0F, 3.0F, 2.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.75F, -0.6667F));

        class_5610 cube_r1 = mouth.method_32117("cube_r1", class_5606.method_32108().method_32101(0, 0).method_32098(-1.5F, -0.5F, -1.0F, 3.0F, 1.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -0.25F, -1.0F, 0.0F, 3.1416F, 0.0F));

        class_5610 jaw = mouth.method_32117("jaw", class_5606.method_32108().method_32101(0, 3).method_32098(-1.5F, -0.5F, -1.0F, 3.0F, 1.0F, 2.0F, new class_5605(0.0F)), class_5603.method_32090(0.0F, 0.75F, -1.0F));

        class_5610 left_legs = body.method_32117("left_legs", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

        class_5610 left_first = left_legs.method_32117("left_first", class_5606.method_32108().method_32101(26, 4).method_32098(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(3.5F, -1.0F, -3.4577F));

        class_5610 left_second = left_legs.method_32117("left_second", class_5606.method_32108().method_32101(22, 7).method_32098(-0.5F, -1.1425F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(3.5F, -0.8575F, -1.4843F));

        class_5610 left_third = left_legs.method_32117("left_third", class_5606.method_32108().method_32101(26, 7).method_32098(-0.5F, -1.2435F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(3.5F, -0.7565F, 0.4685F));

        class_5610 left_fourth = left_legs.method_32117("left_fourth", class_5606.method_32108().method_32101(22, 4).method_32098(0.0F, -0.9328F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(2.5F, -1.0672F, 2.5002F));

        class_5610 right_legs = body.method_32117("right_legs", class_5606.method_32108(), class_5603.method_32090(0.0F, 0.0F, 0.0F));

        class_5610 right_first = right_legs.method_32117("right_first", class_5606.method_32108().method_32101(22, 7).method_32098(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-2.5F, -1.0F, -3.5F));

        class_5610 right_second = right_legs.method_32117("right_second", class_5606.method_32108().method_32101(22, 7).method_32098(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-2.5F, -1.0F, -1.5F));

        class_5610 right_third = right_legs.method_32117("right_third", class_5606.method_32108().method_32101(26, 4).method_32098(-0.5F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-2.5F, -1.0F, 0.5F));

        class_5610 right_fourth = right_legs.method_32117("right_fourth", class_5606.method_32108().method_32101(26, 7).method_32098(-1.0F, -1.0F, -0.5F, 1.0F, 2.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(-1.5F, -1.0F, 2.5F));

        class_5610 torso = body.method_32117("torso", class_5606.method_32108().method_32101(4, 4).method_32098(-2.5F, 0.25F, -3.5833F, 5.0F, 2.0F, 7.0F, new class_5605(0.0F))
                .method_32101(1, 24).method_32098(-1.5F, -0.75F, -1.5833F, 1.0F, 1.0F, 1.0F, new class_5605(0.0F))
                .method_32101(0, 21).method_32098(-0.5F, -0.75F, -2.5833F, 1.0F, 1.0F, 6.0F, new class_5605(0.0F))
                .method_32101(1, 24).method_32098(0.5F, -0.75F, -1.5833F, 1.0F, 1.0F, 1.0F, new class_5605(0.0F))
                .method_32101(1, 24).method_32098(-1.5F, -0.75F, 0.4167F, 1.0F, 1.0F, 1.0F, new class_5605(0.0F))
                .method_32101(1, 24).method_32098(0.5F, -0.75F, 0.4167F, 1.0F, 1.0F, 1.0F, new class_5605(0.0F)), class_5603.method_32090(0.5F, -3.25F, -1.4167F));

        class_5610 tail_1 = torso.method_32117("tail_1", class_5606.method_32108().method_32101(17, 14).method_32098(-1.4895F, -0.8249F, -1.7818F, 3.0F, 2.0F, 4.0F, new class_5605(0.0F)), class_5603.method_32091(-0.0105F, 0.6999F, 4.8985F, 0.2182F, 0.0F, 0.0F));

        class_5610 tail_2 = tail_1.method_32117("tail_2", class_5606.method_32108().method_32101(9, 15).method_32098(-0.5F, -1.0F, -1.5F, 1.0F, 2.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0105F, -0.1341F, 3.4619F, 0.2182F, 0.0F, 0.0F));

        class_5610 tail_3 = tail_2.method_32117("tail_3", class_5606.method_32108().method_32101(1, 15).method_32098(-0.5F, -1.0F, -1.5F, 1.0F, 2.0F, 3.0F, new class_5605(0.0F)), class_5603.method_32091(0.0F, -0.2971F, 2.7661F, 0.2182F, 0.0F, 0.0F));
        return class_5607.method_32110(modelData, 32, 32);
    }

	@Override
	public void setAngles(PejelagartoRenderState state) {
        super.method_2819(state);
        this.setHeadAngles(state.field_53447, state.field_53448);

        switch (state.activeAnimation) {
            case ATTACK -> this.attackAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case FALL -> this.fallAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case IDLE_WATER -> this.idlingWaterAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case IDLE -> this.idlingAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case SWIM -> this.swimAnimation.method_71986(state.activeAnimationState, state.field_53328, 1f);
            case WALK -> this.walkingAnimation.method_71981(state.field_53450, state.field_53451, 2f, 2.5f);
            case SIT -> this.sitAnimation.method_71986(state.activeAnimationState, state.field_53328, 2f);
        }
    }

    private void setHeadAngles(float headYaw, float headPitch) {
        headYaw = class_3532.method_15363(headYaw, -30.0F, 30.0F);
        headPitch = class_3532.method_15363(headPitch, -25.0F, 45.0F);

        this.head.field_3675 = headYaw * (float) (Math.PI / 180.0);
        this.head.field_3654 = headPitch * (float) (Math.PI / 180.0);
    }
}