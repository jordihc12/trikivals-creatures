package com.jordi.trikivalscreatures.entity.pejelagarto.render;

import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimation;
import net.minecraft.class_10042;
import net.minecraft.class_7094;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;

public class PejelagartoRenderState extends class_10042 {
    public class_7094 idleAnimationState = new class_7094();
    public class_7094 activeAnimationState = new class_7094();
    public PejelagartoVariant variant;

    public PejelagartoAnimation activeAnimation;

    public boolean inWater;
}
