package com.jordi.trikivalscreatures.entity.pejelagarto;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.ModEntities;
import com.jordi.trikivalscreatures.entity.ai.*;
import com.jordi.trikivalscreatures.entity.goals.IntelligenceManager;
import com.jordi.trikivalscreatures.entity.pejelagarto.ai.*;
import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimation;
import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimatorManager;
import com.jordi.trikivalscreatures.entity.pejelagarto.spit.PejelagartoSpitEntity;
import com.jordi.trikivalscreatures.sound.ModSounds;
import com.jordi.trikivalscreatures.utils.ModTags;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1282;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1321;
import net.minecraft.class_1324;
import net.minecraft.class_1408;
import net.minecraft.class_1429;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2940;
import net.minecraft.class_2943;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3532;
import net.minecraft.class_3730;
import net.minecraft.class_4050;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.class_5321;
import net.minecraft.class_5328;
import net.minecraft.class_5425;
import net.minecraft.class_5766;
import net.minecraft.class_5819;
import net.minecraft.class_6024;
import net.minecraft.class_7;
import net.minecraft.class_9334;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.passive.*;
import net.minecraft.world.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class PejelagartoEntity extends class_1321 implements CustomRangedAttackMob, CustomMeleeAttackMob {

// ANIMATION VARIABLES
    private final PejelagartoAnimatorManager animationManager = new PejelagartoAnimatorManager();

// DATA TRACKER VARIABLES
    public static final class_2940<Integer> VARIANT =
        class_2945.method_12791(PejelagartoEntity.class, class_2943.field_13327);
    private static final class_2940<Boolean> ATTACKING =
        class_2945.method_12791(PejelagartoEntity.class, class_2943.field_13323);
    private static final class_2940<Boolean> SITTING =
            class_2945.method_12791(PejelagartoEntity.class, class_2943.field_13323);

    private final int POISON_ATTACK_DURATION = 100; // 100 / 20 = 5 sec

// MOISTURE LOGIC
    private int moisture = 0;
    private static final int MOISTURE_MAX_THRESHOLD = 600; // 30 seconds of "charging"
    private static final int MOISTURE_MIN_THRESHOLD = 200; // 10 seconds of "charging"

    //region INITIALIZATION
    public PejelagartoEntity(class_1299<? extends class_1321> entityType, class_1937 world) {
        super(entityType, world);
        this.method_5941(class_7.field_18, 4.0F);
        this.field_6207 = new PejelagartoMoveControl(this);
    }

    public static class_5132.class_5133 createPejelagartoAttributes() {
        return class_1429.method_26828()
                .method_26868(class_5134.field_52450, 10.0F)
                .method_26868(class_5134.field_23716, 10.0F)
                .method_26868(class_5134.field_23719, 0.2f)
                .method_26868(class_5134.field_23721, 3f);
    }

    private void setCustomEntityAttributes() {
        //Modifying base attribute values of specific variants
        switch (getVariant()) {
            case JUNGLE -> {
                double speedBaseValue = this.method_45326(class_5134.field_23719);
                class_1324 speedAttr = this.method_5996(class_5134.field_23719);
                if(speedAttr != null) {
                    speedAttr.method_6192(speedBaseValue * 1.2F);
                }
            }
            case SAND -> {
                double attackBaseValue = this.method_45326(class_5134.field_23721);
                class_1324 attackAttr = this.method_5996(class_5134.field_23721);
                if(attackAttr != null) {
                    attackAttr.method_6192(attackBaseValue * 1.2F);
                }

                double healthBaseValue = this.method_45326(class_5134.field_23716);
                class_1324 healthAttr = this.method_5996(class_5134.field_23716);
                if(healthAttr != null) {
                    healthAttr.method_6192(healthBaseValue * 2.0F);
                }
            }
        }
    }

    @Override
    public class_1315 method_5943(class_5425 world, class_1266 difficulty, class_3730 spawnReason,
                                 @Nullable class_1315 entityData) {
        class_5321<class_1959> biome = world.method_23753(this.method_24515()).method_40230().orElseGet(null);
        PejelagartoVariant thisVariant;
        if(biome != null) {
            List<PejelagartoVariant> possibleVariants = new java.util.ArrayList<>(Collections.emptyList());
            List.of(PejelagartoVariant.values()).forEach(variant -> {
                class_5321<class_1959>[] biomeKeys = variant.getSpawnBiomes();

                //Variant cannot spawn in any biome. Returning!!
                if(biomeKeys == null) {
                    return;
                }

                //Variant can spawn in any biome. Adding as possible variant and returning
                if(biomeKeys.length == 0) {
                    possibleVariants.add(variant);
                    return;
                }

                // Variant spawn in specific biomes. Check if current biome is one of those specific biomes.
                if(Arrays.stream(biomeKeys).anyMatch(biomeRegistryKey -> biomeRegistryKey == biome)) {
                    possibleVariants.add(variant);
                }
            });

            thisVariant = class_156.method_32309(possibleVariants, this.field_5974);
        }
        else {
            TrikiValsCreatures.LogStringWarning(this, "No biome detected. Spawning random variant");

            thisVariant = class_156.method_27173(PejelagartoVariant.values(), this.field_5974);
        }
        this.setVariant(thisVariant);
        this.setCustomEntityAttributes();

        return super.method_5943(world, difficulty, spawnReason, entityData);
    }

    public static boolean canSpawn(class_1299<PejelagartoEntity> entity, class_1936 world, class_3730 spawnReason, class_2338 pos, class_5819 random) {
        return world.method_8320(pos.method_10074()).method_26164(ModTags.Blocks.PEJELAGARTO_SPAWNABLE_ON) && method_39448(world, pos);
    }
//endregion

//region DATA TRACKER
    @Override
    protected void method_5693(class_2945.class_9222 builder) {
        super.method_5693(builder);
        builder.method_56912(VARIANT, 0);
        builder.method_56912(ATTACKING, false);
        builder.method_56912(SITTING, false);
    }

    @Override
    protected void method_5652(class_11372 view) {
        super.method_5652(view);
        view.method_71465("Variant", this.getTypeVariant());
        view.method_71465("Moisture", this.moisture);
    }

    @Override
    protected void method_5749(class_11368 view) {
        super.method_5749(view);
        this.field_6011.method_12778(VARIANT, view.method_71424("Variant", 0));
        this.field_6011.method_12778(SITTING, this.method_24345());
        this.moisture = view.method_71424("Moisture", 0);
    }
//endregion

//region ANIMATIONS
    @Override
    protected void method_48565(float posDelta) {
        float f = (this.method_18376() == class_4050.field_18076) ? Math.min(posDelta * 6.0F, 1.0F) : 0;
        this.field_42108.method_48568(f, 0.2F, this.method_6109() ? 3.0F : 1.0F);
    }

    public final PejelagartoAnimatorManager getAnimationManager() {
        return animationManager;
    }

    private void updatePejelagartoAnimations() {
        //Update active animation
        animationManager.updateActiveAnimation(this);

        //Global animations update
        animationManager.updateAnimations(this.field_6012);

        //Stop Attack animation if it's not running
        if(!this.method_6510()) animationManager.stopAnimation(PejelagartoAnimation.ATTACK);
    }
//endregion

//region UPDATE
    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        class_1799 itemStack = player.method_5998(hand);
        if(this.method_6181()) {
            if (itemStack.method_31574(class_1802.field_8469)) {
                player.method_5783(class_3417.field_14779, 1.0F, 1.0F);

                class_1799 poisonPotion = class_1802.field_8436.method_7854();
                class_1844 potionEffectComponent = class_1844.field_49274.method_57398(getStatusEffectInstance());
                poisonPotion.method_57379(class_9334.field_49651, potionEffectComponent);

                class_1799 itemStack2 = class_5328.method_30012(itemStack, player, poisonPotion);
                player.method_6122(hand, itemStack2);

                return class_1269.field_5812;
            }
            else if(itemStack.method_7960()) {
                this.method_24346(!this.method_24345());
                return class_1269.field_5812;
            }
        }
        else {
            if(!this.method_73183().method_8608() && itemStack.method_31574(class_1802.field_8504)) {
                itemStack.method_57008(1, player);
                this.tryTame(player);
                return class_1269.field_52422;
            }
        }

        return super.method_5992(player, hand);
    }

    private void tryTame(class_1657 player) {
        if (this.field_5974.method_43048(3) == 0) {
            this.method_6170(player);
            this.field_6189.method_6340();
            this.method_5980(null);
            this.method_73183().method_8421(this, class_6024.field_30032);
        } else {
            this.method_73183().method_8421(this, class_6024.field_30031);
        }
    }

    private @NotNull class_1293 getStatusEffectInstance() {
        class_1293 customEffect;
        if(method_6109()) {
            customEffect = new class_1293(
                    class_1294.field_5899,
                    100,
                    (getVariant() == PejelagartoVariant.PINK) ? 1 : 0
            );
        }
        else {
            customEffect = new class_1293(
                    class_1294.field_5899,
                    300,
                    (getVariant() == PejelagartoVariant.PINK) ? 2 : 1
            );
        }
        return customEffect;
    }

    @Override
    public void method_5773() {
        super.method_5773();

        //Client update
        if(this.method_73183().method_8608()) {
            updatePejelagartoAnimations();
        }
        //Server update
        else {
            if(this.method_5799()) {
                // Gain moisture
                if (this.moisture < MOISTURE_MAX_THRESHOLD) moisture++;
            } else {
                // Slowly lose moisture while on land
                if (moisture > 0) moisture--;
            }
        }
    }

    public boolean isDehydrated() {
        return this.moisture <= MOISTURE_MIN_THRESHOLD;
    }

    public boolean isFullyHydrated() {
        return this.moisture >= MOISTURE_MAX_THRESHOLD;
    }
//endregion

//region BREEDING
    @Override
    public boolean method_6481(class_1799 stack) {
        return stack.method_31574(class_1802.field_8504);
    }

    public static PejelagartoEntity createNewChild(class_3218 world, class_243 pos, PejelagartoVariant variant) {
        PejelagartoEntity baby = ModEntities.PEJELAGARTO.method_5883(world, class_3730.field_16466);
        if(baby != null) {
            baby.method_7217(true);
            baby.method_5808(
                    pos.method_10216(),
                    pos.method_10214(),
                    pos.method_10215(),
                    class_3532.method_15393(world.field_9229.method_43057() * 360.0F),
                    0.0F);

            // 1 / 200 possibility of baby being albino
            baby.setVariant((baby.field_5974.method_43048(200) == 0) ? PejelagartoVariant.ALBINO : variant);
            baby.setCustomEntityAttributes();
        }
        return baby;
    }

    @Override
    public @Nullable class_1296 method_5613(class_3218 world, class_1296 entity) {
        return ModEntities.PEJELAGARTO.method_5883(world, class_3730.field_16466);
    }
//endregion

//region SOUNDS
    @Override
    protected @Nullable class_3414 method_5994() {
        if(ModSounds.checkEasterEggSound(this)) {
            return ModSounds.EASTER_EGG_AMBIENT;
        }

        return switch (this.getVariant()) {
            case PINK -> PejelagartoSounds.PEJELAGARTO_IDLE_SOUND_PINK;
            case ALBINO -> PejelagartoSounds.PEJELAGARTO_IDLE_SOUND_ALBINO;
            case PLAINS, JUNGLE, SAND -> PejelagartoSounds.PEJELAGARTO_IDLE_SOUND;
        };
    }

    @Override
    protected @Nullable class_3414 method_6011(class_1282 source) {
        return switch (this.getVariant()) {
            case PINK -> PejelagartoSounds.PEJELAGARTO_HURT_SOUND_PINK;
            case ALBINO -> PejelagartoSounds.PEJELAGARTO_HURT_SOUND_ALBINO;
            case PLAINS, JUNGLE, SAND -> PejelagartoSounds.PEJELAGARTO_HURT_SOUND;
        };
    }

    @Override
    protected @Nullable class_3414 method_6002() {
        if(ModSounds.checkEasterEggSound(this)) {
            return ModSounds.EASTER_EGG_DEATH;
        }

        return switch (this.getVariant()) {
            case PINK -> PejelagartoSounds.PEJELAGARTO_DEATH_SOUND_PINK;
            case ALBINO -> PejelagartoSounds.PEJELAGARTO_DEATH_SOUND_ALBINO;
            case PLAINS, JUNGLE, SAND -> PejelagartoSounds.PEJELAGARTO_DEATH_SOUND;
        };
    }

    public void method_59928() {
        this.method_5783(this.getAttackSound(), 1.0F, (this.field_5974.method_43057() - this.field_5974.method_43057()) * 0.2F + 1.0F);
    }

    private @Nullable class_3414 getAttackSound() {
        return switch (this.getVariant()) {
            case PINK -> PejelagartoSounds.PEJELAGARTO_ATTACK_SOUND_PINK;
            case ALBINO -> PejelagartoSounds.PEJELAGARTO_ATTACK_SOUND_ALBINO;
            case PLAINS, JUNGLE, SAND -> PejelagartoSounds.PEJELAGARTO_ATTACK_SOUND;
        };
    }
//endregion

//region VARIANT
    public PejelagartoVariant getVariant() {
        return PejelagartoVariant.byId(this.getTypeVariant() & 255);
    }

    private int getTypeVariant() {
        return this.field_6011.method_12789(VARIANT);
    }

    private void setVariant(PejelagartoVariant variant) {
        this.field_6011.method_12778(VARIANT, variant.getId() & 255);
    }
//endregion

//region INTELLIGENCE
    @Override
    protected class_1408 method_5965(class_1937 world) {
        return new class_5766(this, world);
    }

    @Override
    protected void method_5959() {
        // INTELLIGENCE
        IntelligenceManager.setGoals(this, PejelagartoIntelligenceManager::new);
    }

//region Attack Logic
    public void method_19540(boolean attacking) {
        this.field_6011.method_12778(ATTACKING, attacking);
    }

    public boolean method_6510() {
        return this.field_6011.method_12789(ATTACKING);
    }

    @Override
    public boolean method_6121(class_3218 world, class_1297 target) {
        if(!super.method_6121(world, target)) {
            return false;
        }
        else {
            if(target instanceof class_1309) {
                class_1293 customEffect = new class_1293(
                        class_1294.field_5899,
                        POISON_ATTACK_DURATION,
                        (getVariant() == PejelagartoVariant.PINK) ? 1 : 0
                        //If variant is pink: poison 2. If other variants poison 1
                );
                ((class_1309)target).method_37222(customEffect, this);
            }
            return true;
        }
    }

    @Override
    public void method_7105(class_1309 target, float pullProgress) {
        this.spitAt(target);
    }

    private void spitAt(class_1309 target) {
        PejelagartoSpitEntity pejelagartoSpitEntity = new PejelagartoSpitEntity(this.method_73183(), this);
        double d = target.method_23317() - this.method_23317();
        double e = target.method_23323(0.3333333333333333) - pejelagartoSpitEntity.method_23318();
        double f = target.method_23321() - this.method_23321();
        double g = Math.sqrt(d * d + f * f) * 0.2F;
        pejelagartoSpitEntity.method_7485(d, e + g, f, 1.5F, 10.0F);
        if (!this.method_5701()) {
            this.method_73183()
                    .method_43128(
                            null,
                            this.method_23317(),
                            this.method_23318(),
                            this.method_23321(),
                            class_3417.field_14789,
                            this.method_5634(),
                            1.0F,
                            1.0F + (this.field_5974.method_43057() - this.field_5974.method_43057()) * 0.2F
                    );
        }

        this.method_73183().method_8649(pejelagartoSpitEntity);
    }

    @Override
    public int getMeleeAttackRange() {
        return 2;
    }

    @Override
    public boolean canPerformMeleeAttack(class_1309 target) {
        return this.getVariant() != PejelagartoVariant.PLAINS && target != null && !(target instanceof PejelagartoEntity);
    }

    @Override
    public int getRangeAggroMaxAttackRange() {
        return 40;
    }

    @Override
    public int getRangeAggroMinAttackRange() {
        return 4;
    }

    @Override
    public boolean canPerformRangedAttack() {
        return this.getVariant() == PejelagartoVariant.ALBINO;
    }
//endregion

//endregion
    public boolean getIsSitting() {
        return this.field_6011.method_12789(SITTING);
    }

    @Override
    public void method_24346(boolean sitting) {
        super.method_24346(sitting);
        this.field_6011.method_12778(SITTING, sitting);
    }

    @Override
    public boolean method_6049(class_1293 effect) {
        return effect.method_5579() != class_1294.field_5899 && super.method_6049(effect);
    }
}
