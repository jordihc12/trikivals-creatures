package com.jordi.trikivalscreatures.entity.pejelagarto.ai;

import com.jordi.trikivalscreatures.entity.pejelagarto.anims.PejelagartoAnimation;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1314;
import net.minecraft.class_1366;
import net.minecraft.class_3218;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;

public class PejelagartoAttackGoal extends class_1366 {
    private final PejelagartoEntity entity;
    private int attackDelay = 5;
    private int ticksUntilnextAttack = 5;
    private boolean shouldCountTillNextAttack = false;

    public PejelagartoAttackGoal(class_1314 mob, double speed, boolean pauseWhenMobIdle) {
        super(mob, speed, pauseWhenMobIdle);
        entity = (PejelagartoEntity) mob;
    }

    @Override
    public void method_6269() {
        super.method_6269();

        attackDelay = 5;
        ticksUntilnextAttack = 5;
    }

    @Override
    protected void method_6288(class_1309 target) {
        if(isEnemyWithinAttackDistance(target)) {
            shouldCountTillNextAttack = true;

            if(isTimeToStartAttackAnimation()) {
                entity.method_19540(true);
            }

            if(isTimeToAttack()) {
                this.field_6503.method_5988().method_20248(target.method_23317(), target.method_23320(), target.method_23321());
                performAttack(target);
            }
        }
        else {
            resetAttackCooldown();
            shouldCountTillNextAttack = false;
            entity.method_19540(false);
            entity.getAnimationManager().resetAnimationCooldownFor(PejelagartoAnimation.ATTACK);
        }
    }

    private boolean isEnemyWithinAttackDistance(class_1309 pEnemy) {
        float attackRange = this.entity.getMeleeAttackRange();
        //If entity is Albino variant the attack range is doubled
        if(entity.getVariant() == PejelagartoVariant.ALBINO) {
            attackRange *= 2.0F;
        }

        return this.entity.method_5739(pEnemy) <= attackRange;
    }

    protected void resetAttackCooldown() {
        this.ticksUntilnextAttack = this.method_38847(attackDelay * 2);
    }

    protected boolean isTimeToStartAttackAnimation() {
        return this.ticksUntilnextAttack <= attackDelay;
    }

    protected boolean isTimeToAttack() {
        return this.ticksUntilnextAttack <= 0;
    }

    protected void performAttack(class_1309 pEnemy) {
        this.resetAttackCooldown();
        this.field_6503.method_6104(class_1268.field_5808);
        this.field_6503.method_6121((class_3218) (this.field_6503.method_73183()), pEnemy);

        this.entity.method_59928();
    }

    @Override
    public void method_6268() {
        super.method_6268();
        if(shouldCountTillNextAttack) this.ticksUntilnextAttack = Math.max(this.ticksUntilnextAttack - 1, 0);
    }

    @Override
    public void method_6270() {
        entity.method_19540(false);

        super.method_6270();
    }
}
