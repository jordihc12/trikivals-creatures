package com.jordi.trikivalscreatures.entity.pejelagarto.ai;

import com.jordi.trikivalscreatures.blocks.ModBlocks;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlock;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import net.minecraft.class_1303;
import net.minecraft.class_1341;
import net.minecraft.class_174;
import net.minecraft.class_1928;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3468;
import net.minecraft.class_5712;
import net.minecraft.class_5819;

public class PejelagartoMateGoal extends class_1341 {
    private final PejelagartoEntity pejelagarto;
    private final int NUMBER_OF_EGGS = 1;

    public PejelagartoMateGoal(PejelagartoEntity pejelagarto, double speed) {
        super(pejelagarto, speed);
        this.pejelagarto = pejelagarto;
    }

    @Override
    public boolean method_6264() {
        return super.method_6264();
    }

    @Override
    protected void method_6249() {
        class_3222 serverPlayerEntity = this.field_6404.method_6478();
        if (serverPlayerEntity == null && this.field_6406.method_6478() != null) {
            serverPlayerEntity = this.field_6406.method_6478();
        }

        if (serverPlayerEntity != null) {
            serverPlayerEntity.method_7281(class_3468.field_15410);
            class_174.field_1190.method_855(serverPlayerEntity, this.field_6404, this.field_6406, null);
        }

        //Place Egg
        PejelagartoVariant variant = this.pejelagarto.getVariant();
        if(this.field_6406 instanceof PejelagartoEntity pejelagartoMate && this.pejelagarto.method_59922().method_43056()) {
            variant = pejelagartoMate.getVariant();
        }

        class_2680 blockState = ModBlocks.PEJELAGARTO_EGG.method_9564()
                .method_11657(PejelagartoEggBlock.EGGS, NUMBER_OF_EGGS)
                .method_11657(PejelagartoEggBlock.VARIANT, variant);

        field_6405.method_8652(pejelagarto.method_24515().method_10072(), blockState, class_2248.field_31036);
        field_6405.method_43276(class_5712.field_28164, pejelagarto.method_24515().method_10072(), class_5712.class_7397.method_43286(this.pejelagarto, blockState));

        this.field_6404.method_5614(6000);
        this.field_6406.method_5614(6000);
        this.field_6404.method_6477();
        this.field_6406.method_6477();
        class_5819 random = this.field_6404.method_59922();
        if(this.field_6405.method_64395().method_76185(class_1928.field_19391)) {
            this.field_6405.method_8649(new class_1303(this.field_6405, this.field_6404.method_23317(), this.field_6404.method_23318(), this.field_6404.method_23321(), random.method_43048(7) + 1));
        }
    }
}
