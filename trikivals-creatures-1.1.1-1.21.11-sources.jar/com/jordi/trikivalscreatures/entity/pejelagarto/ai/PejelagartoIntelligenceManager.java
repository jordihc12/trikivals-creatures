package com.jordi.trikivalscreatures.entity.pejelagarto.ai;

import com.jordi.trikivalscreatures.entity.ai.CustomEscapeDangerGoal;
import com.jordi.trikivalscreatures.entity.ai.CustomRangedAttackGoal;
import com.jordi.trikivalscreatures.entity.ai.FollowOwnerNoTeleportGoal;
import com.jordi.trikivalscreatures.entity.ai.TerritorialTargetGoal;
import com.jordi.trikivalscreatures.entity.goals.IntelligenceManager;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import net.minecraft.class_1309;
import net.minecraft.class_1352;
import net.minecraft.class_1353;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1379;
import net.minecraft.class_1386;
import net.minecraft.class_1391;
import net.minecraft.class_1399;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.entity.ai.goal.*;

public class PejelagartoIntelligenceManager extends IntelligenceManager<PejelagartoEntity> {
    public PejelagartoIntelligenceManager(PejelagartoEntity entity) {
        super(entity);
    }

    @Override
    public void setGoalsPriv() {
        addGoal(new CustomEscapeDangerGoal(entity, 2.0F, 10, 10));
        addGoal(new CustomRangedAttackGoal(entity,1, entity.getRangeAggroMaxAttackRange(), entity.getRangeAggroMinAttackRange(), 40, 20.0F));
        addGoal(new PejelagartoAttackGoal(entity,1, true));
        addGoal(new PejelagartoMateGoal(entity, 1.15));
        addGoal(new class_1386(entity));
        addGoal(new FollowOwnerNoTeleportGoal(entity, 1.0, 10.0F, 2.0F));
        addGoal(new class_1391(entity, 1.15, stack -> stack.method_31574(class_1802.field_8504), false));
        addGoal(new class_1353(entity, 1.0f));
        addGoal(new class_1352[]{
                new class_1379(entity, 1.0f),
                new PejelagartoWanderInWater(entity, 1.0)
        });
        addGoal(new class_1361(entity, class_1657.class, 1.0f));
        addGoal(new class_1376(entity));

        addTarget(new class_1399(entity));
        addTarget(new TerritorialTargetGoal<>(entity,  class_1309.class, 20, 20));
    }
}
