package com.jordi.trikivalscreatures.entity.pejelagarto.ai;

import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import net.minecraft.class_1367;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_4538;

public class PejelagartoWanderInWater extends class_1367 {
    private final PejelagartoEntity pejelagarto;

    public PejelagartoWanderInWater(PejelagartoEntity pejelagarto, double speed) {
        super(pejelagarto, pejelagarto.method_6109() ? 2.0 : speed, 24);
        this.pejelagarto = pejelagarto;
        this.field_6515 = -1;
    }

    @Override
    public boolean method_6266() {
        return !this.pejelagarto.method_5799() &&
                this.field_6517 <= 1200 &&
                this.pejelagarto.isFullyHydrated() &&
                this.method_6296(this.pejelagarto.method_73183(), this.field_6512);
    }

    @Override
    public boolean method_6264() {
        if(this.pejelagarto.method_5799() && !this.pejelagarto.isDehydrated()) return false;
        return super.method_6264();
    }

    @Override
    public boolean method_6294() {
        return this.field_6517 % 160 == 0;
    }

    @Override
    protected boolean method_6296(class_4538 world, class_2338 pos) {
        return world.method_8320(pos).method_27852(class_2246.field_10382);
    }
}
