package com.jordi.trikivalscreatures.entity.pejelagarto.ai;

import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import net.minecraft.class_1335;
import net.minecraft.class_3532;
import net.minecraft.class_5134;

public class PejelagartoMoveControl extends class_1335 {
    private final PejelagartoEntity pejelagarto;

    public PejelagartoMoveControl(PejelagartoEntity pejelagarto) {
        super(pejelagarto);
        this.pejelagarto = pejelagarto;
    }

    private void updateVelocity() {
        if (this.pejelagarto.method_5799()) {
            this.pejelagarto.method_18799(this.pejelagarto.method_18798().method_1031(0.0, 0.005, 0.0));
            this.pejelagarto.method_6125(Math.max(this.pejelagarto.method_6029() * 1.05f, 0.08F));

            if (this.pejelagarto.method_6109()) {
                this.pejelagarto.method_6125(Math.max(this.pejelagarto.method_6029(), 0.06F));
            }
        } else if (this.pejelagarto.method_24828()) {
            this.pejelagarto.method_6125(Math.max(this.pejelagarto.method_6029(), 0.06F));
        }
    }

    @Override
    public void method_6240() {
        this.updateVelocity();
        if (this.field_6374 == class_1336.field_6378 && !this.pejelagarto.method_5942().method_6357()) {
            double d = this.field_6370 - this.pejelagarto.method_23317();
            double e = this.field_6369 - this.pejelagarto.method_23318();
            double f = this.field_6367 - this.pejelagarto.method_23321();
            double g = Math.sqrt(d * d + e * e + f * f);
            if (g < 1.0E-5F) {
                this.field_6371.method_6125(0.0F);
            } else {
                e /= g;
                float h = (float)(class_3532.method_15349(f, d) * 180.0F / (float)Math.PI) - 90.0F;
                this.pejelagarto.method_36456(this.method_6238(this.pejelagarto.method_36454(), h, 90.0F));
                this.pejelagarto.field_6283 = this.pejelagarto.method_36454();
                float i = (float)(this.field_6372 * this.pejelagarto.method_45325(class_5134.field_23719));
                this.pejelagarto.method_6125(class_3532.method_16439(0.125F, this.pejelagarto.method_6029(), i));
                this.pejelagarto.method_18799(this.pejelagarto.method_18798().method_1031(0.0, this.pejelagarto.method_6029() * e * 0.1, 0.0));
            }
        } else {
            super.method_6240();
        }
    }
}
