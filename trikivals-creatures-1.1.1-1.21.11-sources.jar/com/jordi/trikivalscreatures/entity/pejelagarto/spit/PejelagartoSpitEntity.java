package com.jordi.trikivalscreatures.entity.pejelagarto.spit;

import com.jordi.trikivalscreatures.entity.ModEntities;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1675;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2604;
import net.minecraft.class_2945;
import net.minecraft.class_3218;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4970;

public class PejelagartoSpitEntity extends class_1676 {
    private final int POISON_ATTACK_DURATION = 300;

    public PejelagartoSpitEntity(class_1299<? extends PejelagartoSpitEntity> entityEntityType, class_1937 world) {
        super(entityEntityType, world);
    }

    public PejelagartoSpitEntity(class_1937 world, PejelagartoEntity owner) {
        this(ModEntities.PEJELAGARTO_SPIT, world);
        this.method_7432(owner);
        this.method_5814(
                owner.method_23317() - (owner.method_17681() + 1.0F) * 0.5 * class_3532.method_15374(owner.field_6283 * (float) (Math.PI / 180.0)),
                owner.method_23320(),
                owner.method_23321() + (owner.method_17681() + 1.0F) * 0.5 * class_3532.method_15362(owner.field_6283 * (float) (Math.PI / 180.0))
        );
    }

    @Override
    public void method_5773() {
        super.method_5773();
        class_243 vec3d = this.method_18798();
        class_239 hitResult = class_1675.method_49997(this, this::method_26958);
        this.method_7488(hitResult);
        double d = this.method_23317() + vec3d.field_1352;
        double e = this.method_23318() + vec3d.field_1351;
        double f = this.method_23321() + vec3d.field_1350;
        this.method_26962();
        if (this.method_73183().method_29546(this.method_5829()).noneMatch(class_4970.class_4971::method_26215)) {
            this.method_31472();
        } else if (this.method_5799()) {
            this.method_31472();
        } else {
            this.method_18799(vec3d.method_1021(0.99F));
            if (!this.method_5740()) {
                this.method_18799(this.method_18798().method_1031(0.0, -0.06F, 0.0));
            }

            this.method_5814(d, e, f);
        }
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        super.method_7454(entityHitResult);
        if (this.method_24921() instanceof class_1309 livingEntity && this.method_73183() instanceof class_3218 serverWorld) {
            class_1297 entity = entityHitResult.method_17782();
            entity.method_64397(serverWorld, this.method_48923().method_48800(this, livingEntity), 1.0F);

            class_1293 customEffect = new class_1293(
                    class_1294.field_5899,
                    POISON_ATTACK_DURATION,
                    1
            );
            ((class_1309)entity).method_6092(customEffect);
        }
    }

    @Override
    protected void method_24920(class_3965 blockHitResult) {
        super.method_24920(blockHitResult);
        if (!this.method_73183().method_8608()) {
            this.method_31472();
        }
    }

    @Override
    protected void method_5693(class_2945.class_9222 builder) {
    }

    @Override
    public void method_31471(class_2604 packet) {
        super.method_31471(packet);
        double d = packet.method_73084().method_10216();
        double e = packet.method_73084().method_10214();
        double f = packet.method_73084().method_10215();

        for (int i = 0; i < 7; i++) {
            double g = 0.4 + 0.1 * i;
            this.method_73183().method_8406(class_2398.field_11228, this.method_23317(), this.method_23318(), this.method_23321(), d * g, e, f * g);
        }

        this.method_18800(d, e, f);
    }
}
