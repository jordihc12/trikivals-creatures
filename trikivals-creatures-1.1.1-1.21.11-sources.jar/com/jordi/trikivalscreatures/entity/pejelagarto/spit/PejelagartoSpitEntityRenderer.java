package com.jordi.trikivalscreatures.entity.pejelagarto.spit;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_581;
import net.minecraft.class_7833;
import net.minecraft.class_897;

@Environment(EnvType.CLIENT)
public class PejelagartoSpitEntityRenderer extends class_897<PejelagartoSpitEntity, PejelagartoSpitEntityRenderState> {
    private static final class_2960 TEXTURE = class_2960.method_60654("textures/entity/llama/spit.png");
    private final class_581 model;

    public PejelagartoSpitEntityRenderer(class_5617.class_5618 context) {
        super(context);
        this.model = new class_581(context.method_32167(class_5602.field_27612));
    }

    public void render(
            PejelagartoSpitEntityRenderState pejelagartoSpitEntityRenderState,
            class_4587 matrixStack,
            class_11659 orderedRenderCommandQueue,
            class_12075 cameraRenderState
    ) {
        matrixStack.method_22903();
        matrixStack.method_46416(0.0F, 0.15F, 0.0F);
        matrixStack.method_22907(class_7833.field_40716.rotationDegrees(pejelagartoSpitEntityRenderState.yaw - 90.0F));
        matrixStack.method_22907(class_7833.field_40718.rotationDegrees(pejelagartoSpitEntityRenderState.pitch));

        orderedRenderCommandQueue.method_73489(
                this.model,
                pejelagartoSpitEntityRenderState,
                matrixStack,
                this.model.method_23500(TEXTURE),
                pejelagartoSpitEntityRenderState.field_61820,
                class_4608.field_21444,
                pejelagartoSpitEntityRenderState.field_61821,
                null
        );
        matrixStack.method_22909();
        super.method_3936(pejelagartoSpitEntityRenderState, matrixStack, orderedRenderCommandQueue, cameraRenderState);
    }

    public PejelagartoSpitEntityRenderState method_55269() {
        return new PejelagartoSpitEntityRenderState();
    }

    public void updateRenderState(PejelagartoSpitEntity pejelagartoSpitEntity, PejelagartoSpitEntityRenderState pejelagartoRenderState, float f) {
        super.method_62354(pejelagartoSpitEntity, pejelagartoRenderState, f);
        pejelagartoRenderState.pitch = pejelagartoSpitEntity.method_61414(f);
        pejelagartoRenderState.yaw = pejelagartoSpitEntity.method_61415(f);
    }
}
