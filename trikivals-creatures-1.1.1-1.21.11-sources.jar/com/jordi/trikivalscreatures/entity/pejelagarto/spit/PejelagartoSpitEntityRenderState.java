package com.jordi.trikivalscreatures.entity.pejelagarto.spit;

import net.minecraft.class_10017;

public class PejelagartoSpitEntityRenderState extends class_10017 {
    public float yaw;
    public float pitch;
}
