package com.jordi.trikivalscreatures.entity.client;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import net.minecraft.class_2960;
import net.minecraft.class_5601;

//Helper class that creates custom entity model layers
public class ModModelLayers {
    public static final class_5601 PEJELAGARTO =
            new class_5601(class_2960.method_60655(TrikiValsCreatures.MOD_ID, "pejelagarto"), "main");
}
