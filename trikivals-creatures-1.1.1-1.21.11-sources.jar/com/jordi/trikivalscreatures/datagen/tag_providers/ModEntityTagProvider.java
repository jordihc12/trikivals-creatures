package com.jordi.trikivalscreatures.datagen.tag_providers;

import com.jordi.trikivalscreatures.entity.ModEntities;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_3483;
import net.minecraft.class_7225;
import java.util.concurrent.CompletableFuture;

public class ModEntityTagProvider extends FabricTagProvider.EntityTypeTagProvider {
    public ModEntityTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 wrapperLookup) {
        valueLookupBuilder(class_3483.field_46233)
                .method_71558(
                        ModEntities.PEJELAGARTO,
                        ModEntities.DRACOPEZ
                );

        // Palgaster can wear a saddle (vanilla saddle equip logic)
        valueLookupBuilder(class_3483.field_55932)
                .method_71554(ModEntities.PALGASTER);
    }
}
