package com.jordi.trikivalscreatures.datagen.properties;

import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlock;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10494;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_638;
import net.minecraft.class_811;
import net.minecraft.class_9275;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public record PejelagartoVariantProperty() implements class_10494<PejelagartoVariant> {
    public static final Codec<PejelagartoVariant> VALUE_CODEC = PejelagartoVariant.CODEC;
    public static final class_10494.class_10495<PejelagartoVariantProperty, PejelagartoVariant> TYPE = class_10494.class_10495.method_65686(
            MapCodec.unit(new PejelagartoVariantProperty()), VALUE_CODEC
    );

    @Override
    public @Nullable PejelagartoVariant method_65676(class_1799 stack, @Nullable class_638 world, @Nullable class_1309 user, int seed, class_811 displayContext) {
        class_9275 blockStateComponent = stack.method_58694(class_9334.field_49623);
        if(blockStateComponent != null && !blockStateComponent.method_57414()) {
            return blockStateComponent.method_57418(PejelagartoEggBlock.VARIANT);
        }
        return PejelagartoVariant.PLAINS;
    }

    @Override
    public Codec<PejelagartoVariant> method_67287() {
        return VALUE_CODEC;
    }

    @Override
    public class_10495<? extends class_10494<PejelagartoVariant>, PejelagartoVariant> method_65674() {
        return TYPE;
    }
}
