package com.jordi.trikivalscreatures.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2446;
import net.minecraft.class_7225;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends FabricRecipeProvider {
    public ModRecipeProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected class_2446 method_62766(class_7225.class_7874 registryLookup, class_8790 exporter) {
        return new class_2446(registryLookup, exporter) {
            private void customSmithingTemplateCopyingRecipe(class_1935 template, class_1935 resource) {
                this.method_62747(class_7800.field_40642, template, 2)
                        .method_10434('#', resource)
                        .method_10434('S', template)
                        .method_10439("###")
                        .method_10439("#S#")
                        .method_10439("###")
                        .method_10429(method_32807(template), this.method_10426(template))
                        .method_10431(this.field_53721);
            }

            public void customSmithingTemplateCopyingRecipe(class_1935 template, class_1856 resource) {
                this.method_62747(class_7800.field_40642, template, 2)
                        .method_10428('#', resource)
                        .method_10434('S', template)
                        .method_10439("###")
                        .method_10439("#S#")
                        .method_10439("###")
                        .method_10429(method_32807(template), this.method_10426(template))
                        .method_10431(this.field_53721);
            }

            @Override
            public void method_10419() {
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41946, class_1802.field_8328);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41947, class_1802.field_20412);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41948, class_1802.field_20384);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41949, class_1802.field_20412);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41950, class_1802.field_20392);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41951, class_1802.field_29025);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41952, class_1802.field_20399);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41953, class_1802.field_20412);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41954, class_1802.field_20404);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41955, class_1802.field_23843);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41956, class_1802.field_8328);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_41957, class_1802.field_20393);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_43198, class_1802.field_29025);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_43196, class_1802.field_8260);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_43197, class_1802.field_8260);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_43199, class_1802.field_8260);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_43200, class_1802.field_8260);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_49817, class_1802.field_49821);
                this.customSmithingTemplateCopyingRecipe(class_1802.field_49818, class_1856.method_8091(class_1802.field_27071, class_1802.field_27039));
            }
        };
    }

    @Override
    public String method_10321() {
        return "ModRecipeProvider";
    }
}
