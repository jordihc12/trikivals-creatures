package com.jordi.trikivalscreatures.datagen;

import com.jordi.trikivalscreatures.blocks.ModBlocks;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlock;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_2248;
import net.minecraft.class_44;
import net.minecraft.class_4488;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import java.util.concurrent.CompletableFuture;

public class ModBlockLootTableProvider extends FabricBlockLootTableProvider {
    public ModBlockLootTableProvider(FabricDataOutput dataOutput, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(dataOutput, registryLookup);
    }

    private class_52.class_53 pejelagartoEgg(class_2248 drop) {
        return class_52.method_324().method_336(class_55.method_347()
            .method_352(class_44.method_32448(1.0F))
            .method_351(class_77.method_411(drop)
                .method_438(class_4488.method_21892(drop).method_21898(PejelagartoEggBlock.VARIANT))
            )
        );
    }

    @Override
    public void method_10379() {
        method_45994(ModBlocks.PEJELAGARTO_EGG, this::pejelagartoEgg);
    }
}
