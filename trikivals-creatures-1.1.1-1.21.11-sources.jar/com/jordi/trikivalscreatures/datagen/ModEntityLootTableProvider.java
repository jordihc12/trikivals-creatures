package com.jordi.trikivalscreatures.datagen;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.utils.ModLootTableBuilder;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricEntityLootTableProvider;
import net.minecraft.class_1802;
import net.minecraft.class_221;
import net.minecraft.class_225;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;

public class ModEntityLootTableProvider extends FabricEntityLootTableProvider {

    private final ModLootTableBuilder tableBuilder;

    private final Map<class_2960, class_52.class_53> lootTables;

    public ModEntityLootTableProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registryLookup) {
        super(output, registryLookup);

        this.tableBuilder = new ModLootTableBuilder();
        this.lootTables = new HashMap<>();
    }

    public void method_10400() {
    }

    private void pejelagartoLootTable() {
        this.lootTables.put(class_2960.method_60655(TrikiValsCreatures.MOD_ID, "entities/pejelagarto"),
            tableBuilder.createTable()
                .addPool(
                    tableBuilder.createPool()
                        .addItem(
                            tableBuilder.createItem(class_1802.field_8477)
                                .setPoolCount(0, 1)
                                .setPoolLootingModifier(this.field_51846, 0, 2)
                                .getItem()
                        ).getPool()
                ).addPool(
                    tableBuilder.createPool()
                        .addItem( tableBuilder.createItem(class_1802.field_8603).getItem() )
                        .addPoolCondition(class_221.method_939())
                        .addPoolCondition(class_225.method_953(field_51846, 50.0F, 3.0F))
                        .getPool()
                ).getTable());
    }

    @Override
    public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> biConsumer) {
        super.method_10399(biConsumer);

        pejelagartoLootTable();
    }
}
