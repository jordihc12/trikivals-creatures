package com.jordi.trikivalscreatures.datagen;

import com.jordi.trikivalscreatures.blocks.ModBlocks;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlock;
import com.jordi.trikivalscreatures.client.model.ModModelIds;
import com.jordi.trikivalscreatures.client.model.ModModels;
import com.jordi.trikivalscreatures.client.tint.DracoPezFinsTintSource;
import com.jordi.trikivalscreatures.datagen.properties.PejelagartoVariantProperty;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import com.jordi.trikivalscreatures.items.ModItems;
import com.jordi.trikivalscreatures.utils.ModModelUtils;
import net.fabricmc.fabric.api.client.datagen.v1.provider.FabricModelProvider;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_10410;
import net.minecraft.class_10411;
import net.minecraft.class_10439;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.client.data.*;
import java.util.Optional;
import java.util.function.BiConsumer;

//Helper class that generates custom mod data
public class ModModelProvider extends FabricModelProvider {
    public ModModelProvider(FabricDataOutput output) {
        super(output);
    }

    private void registerPejelagartoEggItem(class_1792 item) {

    }

    private class_2960 getPejelagartoEggModel(Integer eggs, PejelagartoVariant variant, Integer hatch,
                                                BiConsumer<class_2960, class_10411> modelCollector) {
        return ModModelUtils.getEggHatchModelTemplateWithVariant(hatch, eggs, ModBlocks.PEJELAGARTO_EGG,
                variant.method_15434(), modelCollector,
                new class_4942[] {
                        ModModels.TEMPLATE_PEJELAGARTO_EGG,
                        ModModels.TEMPLATE_TWO_PEJELAGARTO_EGGS,
                        ModModels.TEMPLATE_THREE_PEJELAGARTO_EGGS,
                        ModModels.TEMPLATE_FOUR_PEJELAGARTO_EGGS
        });
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {
        //Register Pejelagarto Eggs
        blockStateModelGenerator.field_22830.accept(
            class_4925.method_67852(ModBlocks.PEJELAGARTO_EGG)
                .method_67859(
                    class_4926.method_67866(PejelagartoEggBlock.EGGS, PejelagartoEggBlock.VARIANT, PejelagartoEggBlock.HATCH)
                        .method_25805(((eggInt, variant, hatchInt) ->
                            class_4910.method_67839(
                                class_4910.method_67806(
                                        this.getPejelagartoEggModel(eggInt, variant, hatchInt, blockStateModelGenerator.field_22831)))))
                )
        );
    }

    private void generatePejelagartoEggItemModel(class_4915 itemModelGenerator) {
        class_10439.class_10441 unbakedAlbino = class_10410.method_65481(
                itemModelGenerator.method_65438(ModItems.PEJELAGARTO_EGG_ITEM, "_albino", class_4943.field_22938));
        class_10439.class_10441 unbakedJungle = class_10410.method_65481(
                itemModelGenerator.method_65438(ModItems.PEJELAGARTO_EGG_ITEM, "_jungle", class_4943.field_22938));
        class_10439.class_10441 unbakedPink = class_10410.method_65481(
                itemModelGenerator.method_65438(ModItems.PEJELAGARTO_EGG_ITEM, "_pink", class_4943.field_22938));
        class_10439.class_10441 unbakedPlains = class_10410.method_65481(
                itemModelGenerator.method_65438(ModItems.PEJELAGARTO_EGG_ITEM, "_plains", class_4943.field_22938));
        class_10439.class_10441 unbakedSand = class_10410.method_65481(
                itemModelGenerator.method_65438(ModItems.PEJELAGARTO_EGG_ITEM, "_sand", class_4943.field_22938));

        itemModelGenerator.field_55245.method_75343(
                ModItems.PEJELAGARTO_EGG_ITEM,
                class_10410.method_65496(new PejelagartoVariantProperty(),
                        class_10410.method_65497(PejelagartoVariant.ALBINO, unbakedAlbino),
                        class_10410.method_65497(PejelagartoVariant.JUNGLE, unbakedJungle),
                        class_10410.method_65497(PejelagartoVariant.PINK, unbakedPink),
                        class_10410.method_65497(PejelagartoVariant.PLAINS, unbakedPlains),
                        class_10410.method_65497(PejelagartoVariant.SAND, unbakedSand)
                )
        );
    }

    // Bucket: layer0 = bucket + water + body, layer1 = fins (tinted with the fin color stored in the bucket)
    private void generateDracoPezBucketItemModel(class_4915 itemModelGenerator) {
        DracoPezFinsTintSource.register();
        class_2960 model = itemModelGenerator.method_65431(ModItems.DRACOPEZ_BUCKET,
                ModModelIds.getItemModelId(ModItems.DRACOPEZ_BUCKET),
                ModModelIds.getItemSubModelId(ModItems.DRACOPEZ_BUCKET, "_fins"));
        itemModelGenerator.field_55245.method_75343(ModItems.DRACOPEZ_BUCKET,
                class_10410.method_65483(model, class_10410.method_65480(-1), DracoPezFinsTintSource.INSTANCE));
    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {
        itemModelGenerator.method_65442(ModItems.PEJELAGARTO_SPAWN_EGG, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.DRACOPEZ_SPAWN_EGG, class_4943.field_22938);
        itemModelGenerator.method_65442(ModItems.PALGASTER_SPAWN_EGG, class_4943.field_22938);
        generateDracoPezBucketItemModel(itemModelGenerator);
        generatePejelagartoEggItemModel(itemModelGenerator);
    }
}
