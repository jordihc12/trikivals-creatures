package com.jordi.trikivalscreatures.world.gen;

import com.jordi.trikivalscreatures.entity.ModEntities;
import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.class_1311;
import net.minecraft.class_1317;
import net.minecraft.class_1972;
import net.minecraft.class_2902;
import net.minecraft.class_9169;

//Helper class that adds custom mobs to world spawn generation
public class ModEntityGeneration {
    public static void addSpawns() {
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9451, class_1972.field_9417, class_1972.field_9462, class_1972.field_9424),
                class_1311.field_6294,
                ModEntities.PEJELAGARTO, 35, 3, 6);

        class_1317.method_20637(ModEntities.PEJELAGARTO, class_9169.field_48745,
                class_2902.class_2903.field_13203, PejelagartoEntity::canSpawn);

        // DracoPez: warm waters and the water of lush caves (where glow berries grow)
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(class_1972.field_9408, class_1972.field_9441,
                        class_1972.field_9439, class_1972.field_29218),
                class_1311.field_24460,
                ModEntities.DRACOPEZ, 6, 1, 3);

        class_1317.method_20637(ModEntities.DRACOPEZ, class_9169.field_48743,
                class_2902.class_2903.field_13203, DracoPezEntity::canSpawn);
    }
}
