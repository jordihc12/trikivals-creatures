package com.jordi.trikivalscreatures.items;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.blocks.ModBlocks;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlockItem;
import com.jordi.trikivalscreatures.entity.ModEntities;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroupEntries;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3417;
import net.minecraft.class_3612;
import net.minecraft.class_5321;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import java.util.function.Function;

//Helper class that initializes custom Items
public class ModItems {

    public static final class_1792 PEJELAGARTO_SPAWN_EGG = registerSpawnEgg(ModEntities.PEJELAGARTO);

    public static final class_1792 PEJELAGARTO_EGG_ITEM = registerItem("pejelagarto_egg",
            settings -> new PejelagartoEggBlockItem(ModBlocks.PEJELAGARTO_EGG, settings));

    public static final class_1792 DRACOPEZ_SPAWN_EGG = registerSpawnEgg(ModEntities.DRACOPEZ);
    public static final class_1792 PALGASTER_SPAWN_EGG = registerSpawnEgg(ModEntities.PALGASTER);

    public static final class_1792 DRACOPEZ_BUCKET = registerItem("dracopez_bucket",
            settings -> new DracoPezBucketItem(ModEntities.DRACOPEZ, class_3612.field_15910, class_3417.field_14912,
                    settings.method_7889(1).method_57349(class_9334.field_49610, class_9279.field_49302)));

    private static void addItemsToSpawnEggsItemGroup(FabricItemGroupEntries entries) {
        entries.method_45421(PEJELAGARTO_SPAWN_EGG);
        entries.method_45421(DRACOPEZ_SPAWN_EGG);
        entries.method_45421(PALGASTER_SPAWN_EGG);
    }

    private static class_1792 registerSpawnEgg(class_1299<?> type) {
        return registerItem(class_5321.method_29179(class_7924.field_41197,
                class_1299.method_5890(type).method_48331("_spawn_egg")),
                class_1826::new,
                new class_1792.class_1793().method_72499(type));
    }

    private static class_1792 registerItem(class_5321<class_1792> key, Function<class_1792.class_1793, class_1792> factory, class_1792.class_1793 settings) {
        return class_2378.method_39197(class_7923.field_41178, key, factory.apply(settings.method_63686(key)));
    }

    private static class_1792 registerItem(String name, Function<class_1792.class_1793, class_1792> function) {
        return class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name),
                function.apply(new class_1792.class_1793().method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name)))));
    }

    public static void registerModItems() {
        TrikiValsCreatures.LOGGER.info("Registering Mod items for " + TrikiValsCreatures.MOD_ID);

        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(ModItems::addItemsToSpawnEggsItemGroup);
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_41060).register(entries -> entries.method_45421(DRACOPEZ_BUCKET));
    }
}
