package com.jordi.trikivalscreatures.items;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlock;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9275;
import net.minecraft.class_9334;

public class ModItemGroups {

    public static final class_1761 TRIKIVALS_CREATURES_GROUP = class_2378.method_10230(class_7923.field_44687,
        class_2960.method_60655(TrikiValsCreatures.MOD_ID, "trikivals_items_group"), FabricItemGroup.builder()
            .method_47321(class_2561.method_43471("itemgroup.trikivals-creatures.creatures"))
            .method_47320(() -> new class_1799(ModItems.PEJELAGARTO_SPAWN_EGG))
            .method_47317((displayContext, entries) -> {
                //Adding Pejelagarto Eggs
                ModItemGroups.addPejelagartoEggEntries(entries);

                //Adding Pejelagarto entity Spawn egg
                entries.method_45421(ModItems.PEJELAGARTO_SPAWN_EGG);

                //Adding DracoPez spawn egg and bucket
                entries.method_45421(ModItems.DRACOPEZ_SPAWN_EGG);
                entries.method_45421(ModItems.DRACOPEZ_BUCKET);

                //Adding Palgaster spawn egg
                entries.method_45421(ModItems.PALGASTER_SPAWN_EGG);
            }).method_47324());

    //Add Pejelagarto Egg variants to TrikiVals creatures group
    private static void addPejelagartoEggEntries(class_1761.class_7704 entries) {
        for (PejelagartoVariant variant : PejelagartoVariant.values()) {
            //Create new Stack for the egg variant
            class_1799 pejelagartoEggItemStack = new class_1799(ModItems.PEJELAGARTO_EGG_ITEM);

            //Request nbt with the variant from PejelagartoEggBlock
            class_9275 blockStateComponent =
                    class_9275.field_49284.method_57420(PejelagartoEggBlock.VARIANT, variant);

            pejelagartoEggItemStack.method_57379(class_9334.field_49623, blockStateComponent);

            //Add pejelagartoEggItemStack to item group
            entries.method_45420(pejelagartoEggItemStack);
        }
    }

    public static void registerItemGroups() {
        TrikiValsCreatures.LOGGER.info("Registering Mod Item Groups for " + TrikiValsCreatures.MOD_ID); }
}
