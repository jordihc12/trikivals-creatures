package com.jordi.trikivalscreatures.items;

import com.jordi.trikivalscreatures.entity.dracopez.DracoPezEntity;
import java.util.function.Consumer;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1767;
import net.minecraft.class_1785;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

/**
 * Bucket with a DracoPez inside. Keeps its size and fin color, shows them in the tooltip
 * and the fins drawn on the item are tinted with the stored color.
 */
public class DracoPezBucketItem extends class_1785 {
    public DracoPezBucketItem(class_1299<? extends class_1308> type, class_3611 fluid, class_3414 emptyingSound, class_1793 settings) {
        super(type, fluid, emptyingSound, settings);
    }

    @Override
    public void method_67187(class_1799 stack, class_9635 context, class_10712 displayComponent,
                              Consumer<class_2561> textConsumer, class_1836 type) {
        class_9279 data = stack.method_58695(class_9334.field_49610, class_9279.field_49302);
        if (data.method_57458()) {
            return;
        }

        class_2487 nbt = data.method_57461();
        class_1767 color = class_1767.method_7791(nbt.method_68083("FinColor", class_1767.field_7952.method_7789()));
        float lengthBlocks = nbt.method_66563("AdultScale", DracoPezEntity.MIN_SCALE) * DracoPezEntity.MODEL_LENGTH_BLOCKS;
        boolean baby = nbt.method_68083("Age", 0) < 0;

        textConsumer.accept(class_2561.method_43469("tooltip.trikivals-creatures.dracopez.fins",
                class_2561.method_43471("color.minecraft." + color.method_7792())).method_27692(class_124.field_1080));

        String sizeKey = lengthBlocks < 1.65F ? "small" : (lengthBlocks < 1.85F ? "medium" : "large");
        textConsumer.accept(class_2561.method_43469("tooltip.trikivals-creatures.dracopez.size",
                class_2561.method_43471("tooltip.trikivals-creatures.dracopez.size." + sizeKey),
                String.format("%.2f", lengthBlocks)).method_27692(class_124.field_1080));

        if (baby) {
            textConsumer.accept(class_2561.method_43471("tooltip.trikivals-creatures.dracopez.baby").method_27692(class_124.field_1080));
        }
    }
}
