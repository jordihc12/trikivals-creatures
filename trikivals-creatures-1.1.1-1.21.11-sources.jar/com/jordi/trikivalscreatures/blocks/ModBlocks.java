package com.jordi.trikivalscreatures.blocks;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlock;
import com.jordi.trikivalscreatures.blocks.pejelagarto.PejelagartoEggBlockItem;
import java.util.function.Function;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModBlocks {
    public static final class_2248 PEJELAGARTO_EGG = registerBlockWithoutBlockItem("pejelagarto_egg",
            settings ->
                    new PejelagartoEggBlock(settings.method_31710(class_3620.field_15986)
                            .method_51369()
                            .method_9632(0.5F)
                            .method_9626(class_2498.field_11533)
                            .method_9640()
                            .method_22488()
                            .method_50012(class_3619.field_15971)));

    private static class_2248 registerBlock(String name, Function<class_4970.class_2251, class_2248> function) {
        class_2248 toRegister = function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name))));
        registerBlockItem(name, toRegister);
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name), toRegister);
    }

    private static class_2248 registerBlockWithoutBlockItem(String name, Function<class_4970.class_2251, class_2248> function) {
        return class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name),
                function.apply(class_4970.class_2251.method_9637().method_63500(class_5321.method_29179(class_7924.field_41254, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name)))));
    }

    private static void registerBlockItem(String name, class_2248 block) {
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name),
                new class_1747(block, new class_1792.class_1793().method_63685()
                        .method_63686(class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name)))));
    }

    public static void registerModBlocks() {
        TrikiValsCreatures.LOGGER.info("Registering Mod Blocks for " + TrikiValsCreatures.MOD_ID);

    }
}
