package com.jordi.trikivalscreatures.blocks.pejelagarto;

import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_9275;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class PejelagartoEggBlockItem extends class_1747 {
    public PejelagartoEggBlockItem(class_2248 block, class_1793 settings) {
        super(block, settings);
    }

    PejelagartoVariant getVariant(class_1799 stack, PejelagartoVariant defaultValue) {
        PejelagartoVariant variant = getVariant(stack);
        return variant != null ? variant : defaultValue;
    }

    PejelagartoVariant getVariant(class_1799 stack) {
        class_9275 blockStateComponent = stack.method_58694(class_9334.field_49623);
        if(blockStateComponent != null && !blockStateComponent.method_57414()) {
            return blockStateComponent.method_57418(PejelagartoEggBlock.VARIANT);
        }

        return null;
    }

    @Override
    protected boolean method_7710(class_2338 pos, class_1937 world, @Nullable class_1657 player, class_1799 stack, class_2680 state) {
        boolean bl = super.method_7710(pos, world, player, stack, state);
        if(method_7711() instanceof PejelagartoEggBlock pejelagartoEggBlock) {
            pejelagartoEggBlock.setVariant(getVariant(stack, PejelagartoVariant.PLAINS));
        }

        return bl;
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        String variant = getVariant(stack).method_15434();

        return class_2561.method_43471(this.method_7876() + "." + variant);
    }
}
