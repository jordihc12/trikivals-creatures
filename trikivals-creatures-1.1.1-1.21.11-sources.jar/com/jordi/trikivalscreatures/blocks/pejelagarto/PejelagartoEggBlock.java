package com.jordi.trikivalscreatures.blocks.pejelagarto;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoEntity;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoVariant;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2754;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5712;
import net.minecraft.class_5819;
import net.minecraft.class_6088;
import net.minecraft.class_9275;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

public class PejelagartoEggBlock extends class_2248 {
    public static final class_2758 EGGS = class_2741.field_12509;
    public static final class_2758 HATCH = class_2741.field_12530;
    public static final class_2754<PejelagartoVariant> VARIANT = class_2754.method_11850("variant", PejelagartoVariant.class);

    private static final class_265 SMALL_SHAPE = class_2248.method_9541(3.0, 0.0, 3.0, 12.0, 7.0, 12.0);
    private static final class_265 LARGE_SHAPE = class_2248.method_9541(1.0, 0.0, 1.0, 15.0, 7.0, 15.0);

    private static final int HATCH_STAGE_TICKS = 18000;  //15min per stage = 15min * 60sec * 20ticks

    private boolean canHatch = false;

    //region INITIALISATION
    public PejelagartoEggBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(VARIANT, PejelagartoVariant.PLAINS)
                .method_11657(EGGS, 1)
                .method_11657(HATCH, 0)
        );
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(EGGS, VARIANT, HATCH);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return state.method_11654(EGGS) > 1 ? LARGE_SHAPE : SMALL_SHAPE;
    }
//endregion

//region VARIANT
    public void setVariant(PejelagartoVariant variant) {
        this.method_9590(this.field_10647.method_11664().method_11657(VARIANT, variant));
    }

    public PejelagartoVariant getVariantState(class_2680 state) {
        return state.method_11654(VARIANT);
    }

    public PejelagartoVariant getVariantState() {
        return this.method_9564().method_11654(VARIANT);
    }
//endregion

//region EGG LOGIC
    private void breakEgg(class_1937 world, class_2338 pos, class_2680 state) {
        world.method_8396(null, pos, class_3417.field_14687,
                class_3419.field_15245, 0.7F, 0.9F + world.field_9229.method_43057() * 0.2F);
        int i = state.method_11654(EGGS);
        if (i <= 1) {
            world.method_22352(pos, false);
        } else {
            world.method_8652(pos, state.method_11657(EGGS, i - 1), class_2248.field_31028);
            world.method_43276(class_5712.field_28165, pos, class_5712.class_7397.method_43287(state));
            world.method_20290(class_6088.field_31144, pos, class_2248.method_9507(state));
        }
    }

    @Override
    public void method_9556(class_1937 world, class_1657 player, class_2338 pos, class_2680 state,
                           @Nullable class_2586 blockEntity, class_1799 tool) {
        super.method_9556(world, player, pos, state, blockEntity, tool);
        this.breakEgg(world, pos, state);
    }

    @Override
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        this.canHatch = isIncubationBlockBelow(world, pos.method_10074());
        TrikiValsCreatures.LOGGER.info("[PejelagartoEggBlock] Block below allows egg incubation: {}", this.canHatch);
        if(this.canHatch) {
            world.method_20290(class_6088.field_47838, pos, 0);
            world.method_64310(pos, this, HATCH_STAGE_TICKS);   //Time that takes to increase Hatch state
        }
    }

    //endregion

//region HATCH AND INCUBATION

    @Override
    public void method_9588(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if(!this.canHatch) return;

        if(!readyToHatch(state)) {
            world.method_8396(null, pos, class_3417.field_43165, class_3419.field_15245, 0.7F, 0.9F + random.method_43057() * 0.2F);
            world.method_8652(pos, state.method_11657(HATCH, state.method_11654(HATCH) + 1), class_2248.field_31028);
        }
        else {
            world.method_8396(null, pos, class_3417.field_43166, class_3419.field_15245, 0.7F, 0.9F + random.method_43057() * 0.2F);
            world.method_22352(pos, false);
            for (int i = 0; i < state.method_11654(EGGS); i++) {
                class_243 vec3d = pos.method_46558().method_1031(0.3 + i * 0.2, 0.0 , 0.3);
                PejelagartoEntity baby = PejelagartoEntity.createNewChild(world, vec3d, getVariantState(state));
                if(baby != null) {
                    world.method_8649(baby);
                }
            }
        }
    }

    private boolean readyToHatch(class_2680 state) {
        return state.method_11654(HATCH) == 2;
    }

    private boolean isIncubationBlockBelow(class_1922 world, class_2338 pos) {
        return world.method_8320(pos).method_26164(class_3481.field_15466);   //Override BlockTags.SAND with incubation blocks tag
    }

//endregion

//region MULTI-BLOCK

    private boolean isStackValid(class_1799 stack) {
        if(stack.method_7909() instanceof PejelagartoEggBlockItem) {
            class_9275 blockStateComponent = stack.method_58694(class_9334.field_49623);
            if(blockStateComponent == null || blockStateComponent.method_57414()) return false;

            return this.getVariantState() == blockStateComponent.method_57418(VARIANT);
        }

        return false;
    }

    @Override
    public class_1269 method_55765(class_1799 stack, class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        int eggs = state.method_11654(EGGS);
        if(eggs >= 4) return class_1269.field_5811;
        if(!world.method_8608() && isStackValid(stack)) {
            world.method_8652(pos, state.method_11657(EGGS, eggs + 1), field_31028);
            if(!player.method_68878()) {
                stack.method_7934(1);
            }
            return class_1269.field_5812;
        }
        return super.method_55765(stack, state, world, pos, player, hand, hit);
    }

    @Override
    public boolean method_9616(class_2680 state, class_1750 context) {
        return !context.method_8046() &&
                context.method_8041().method_31574(this.method_8389()) && state.method_11654(VARIANT) == this.getVariantState(state) &&
                state.method_11654(EGGS) < 4 || super.method_9616(state, context);
    }
//endregion

    @Override
    public class_1799 method_9574(class_4538 world, class_2338 pos, class_2680 state, boolean includeData) {
        class_1799 stack = super.method_9574(world, pos, state, includeData);

        stack.method_57379(class_9334.field_49623,
                class_9275.field_49284.method_57420(PejelagartoEggBlock.VARIANT, state.method_11654(VARIANT)));

        return stack;
    }


}
