package com.jordi.trikivalscreatures.utils;

import net.minecraft.class_125;
import net.minecraft.class_141;
import net.minecraft.class_1935;
import net.minecraft.class_52;
import net.minecraft.class_5341;
import net.minecraft.class_55;
import net.minecraft.class_5658;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_85;

public class ModLootTableBuilder {

    class_52.class_53 table = null;
    class_55.class_56 pool = null;

    class_85.class_86<?> item = null;

    public ModLootTableBuilder createTable() {
        this.table = class_52.method_324();
        return this;
    }

    public ModLootTableBuilder createPool() {
        this.pool = class_55.method_347();
        return this;
    }

    public class_52.class_53 getTable() {
        return this.table;
    }

    public class_55.class_56 getPool() {
        return this.pool;
    }

    public class_85.class_86<?> getItem() {return this.item; }

    public ModLootTableBuilder addPool(class_55.class_56 pool) {
        this.table.method_336(pool);
        return this;
    }

    public ModLootTableBuilder addRolls(class_5658 rolls) {
        this.pool.method_352(rolls);
        return this;
    }

    public ModLootTableBuilder addItem(class_85.class_86<?> itemDrop) {
        this.pool.method_351(itemDrop);
        return this;
    }

    public ModLootTableBuilder createItem(class_1935 itemDrop) {
        this.item = class_77.method_411(itemDrop);
        return this;
    }

    public ModLootTableBuilder setPoolCount(int min, int max) {
        this.item.method_438(class_141.method_621(class_5662.method_32462(min, max)));
        return this;
    }

    public ModLootTableBuilder setPoolLootingModifier(class_7225.class_7874 registries, float min, float max) {
        this.item.method_438(class_125.method_547(registries, class_5662.method_32462(min, max)));
        return this;
    }

    public ModLootTableBuilder addPoolCondition(class_5341.class_210 condition) {
        this.pool.method_356(condition);
        return this;
    }
}
