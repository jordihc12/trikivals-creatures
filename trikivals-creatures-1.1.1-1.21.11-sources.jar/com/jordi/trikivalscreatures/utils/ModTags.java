package com.jordi.trikivalscreatures.utils;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static class Blocks {
        public static final class_6862<class_2248> PEJELAGARTO_SPAWNABLE_ON = createTag("pejelagarto_spawnable_on");

        private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name));
        }
    }

    public static class Items {
        private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TrikiValsCreatures.MOD_ID, name));
        }
    }
}