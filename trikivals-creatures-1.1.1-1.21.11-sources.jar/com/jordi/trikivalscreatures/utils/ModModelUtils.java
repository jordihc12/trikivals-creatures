package com.jordi.trikivalscreatures.utils;

import com.jordi.trikivalscreatures.client.model.ModModelIds;
import java.util.function.BiConsumer;
import net.minecraft.class_10411;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4944;
import net.minecraft.class_7923;

public class ModModelUtils {

    private static class_2960 getEggModelTemplate(int eggs, String entityEggStr, class_4944 textures,
                                                  BiConsumer<class_2960, class_10411> modelCollector, class_4942[] modelTemplates) {
        switch (eggs) {
            case 1 -> {
                return modelTemplates[0].method_25852(
                        ModModelIds.getNamespacedBlock(entityEggStr),
                        textures,
                        modelCollector);
            }
            case 2 -> {
                return modelTemplates[1].method_25852(
                        ModModelIds.getNamespacedBlock("two_" + entityEggStr),
                        textures,
                        modelCollector);
            }
            case 3 -> {
                return modelTemplates[2].method_25852(
                        ModModelIds.getNamespacedBlock("three_" + entityEggStr),
                        textures,
                        modelCollector);
            }
            case 4 -> {
                return modelTemplates[3].method_25852(
                        ModModelIds.getNamespacedBlock("four_" + entityEggStr),
                        textures,
                        modelCollector);
            }
            default -> throw new UnsupportedOperationException();
        }
    }

    public static class_2960 getEggHatchModelTemplateWithVariant(int hatch, int eggs, class_2248 block, String variant,
                                                                 BiConsumer<class_2960, class_10411> modelCollector, class_4942[] modelTemplates) {
        String blockId = class_7923.field_41175.method_10221(block).method_12832();
        switch (hatch) {
            case 0 -> {
                return getEggModelTemplate(eggs, variant + "_" + blockId,
                        class_4944.method_25875(class_4944.method_25866(block, "_" + variant)), modelCollector, modelTemplates);
            }
            case 1 -> {
                return getEggModelTemplate(eggs, "slightly_cracked_" + variant + "_" + blockId,
                        class_4944.method_25875(class_4944.method_25866(block, "_" + variant + "_slightly_cracked")), modelCollector, modelTemplates);
            }
            case 2 -> {
                return getEggModelTemplate(eggs, "very_cracked_" + variant + "_" + blockId,
                        class_4944.method_25875(class_4944.method_25866(block, "_" + variant + "_very_cracked")), modelCollector, modelTemplates);
            }
            default -> throw new UnsupportedOperationException();
        }
    }

    public static class_2960 getEggHatchModelTemplate(int hatch, int eggs, class_2248 block,
                                                      BiConsumer<class_2960, class_10411> modelCollector, class_4942[] modelTemplates) {
        String blockId = class_7923.field_41175.method_10221(block).method_12832();
        switch (hatch) {
            case 0 -> {
                return getEggModelTemplate(eggs, blockId,
                        class_4944.method_25875(class_4944.method_25860(block)), modelCollector, modelTemplates);
            }
            case 1 -> {
                return getEggModelTemplate(eggs, "slightly_cracked_" + blockId,
                        class_4944.method_25875(class_4944.method_25866(block, "_slightly_cracked")), modelCollector, modelTemplates);
            }
            case 2 -> {
                return getEggModelTemplate(eggs, "very_cracked_" + blockId,
                        class_4944.method_25875(class_4944.method_25866(block, "_very_cracked")), modelCollector, modelTemplates);
            }
            default -> throw new UnsupportedOperationException();
        }
    }
}
