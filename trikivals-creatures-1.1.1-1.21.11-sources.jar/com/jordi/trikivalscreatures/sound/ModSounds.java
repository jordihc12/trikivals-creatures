package com.jordi.trikivalscreatures.sound;

import com.jordi.trikivalscreatures.TrikiValsCreatures;
import com.jordi.trikivalscreatures.entity.pejelagarto.PejelagartoSounds;
import net.minecraft.class_1297;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public class ModSounds {

    public static final class_3414 EASTER_EGG_AMBIENT = ModSounds.registerSoundEvent("easter_egg_ambient");
    public static final class_3414 EASTER_EGG_DEATH = ModSounds.registerSoundEvent("easter_egg_death");

    public static class_3414 registerSoundEvent(String name) {
        class_2960 id = class_2960.method_60655(TrikiValsCreatures.MOD_ID, name);
        return class_2378.method_10230(class_7923.field_41172, id, class_3414.method_47908(id));
    }

    public static boolean checkEasterEggSound(class_1297 entity) {
        class_2561 text = entity.method_5797();
        return text != null && text.getString().equals("TrikiVals_");
    }

    public static void registerSounds() {
        TrikiValsCreatures.LOGGER.info("Registering Sounds for " + TrikiValsCreatures.MOD_ID);

        PejelagartoSounds.registerSounds();
    }
}
